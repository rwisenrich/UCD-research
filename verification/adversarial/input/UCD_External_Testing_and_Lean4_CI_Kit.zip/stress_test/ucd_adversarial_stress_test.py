#!/usr/bin/env python3
"""
UCD Adversarial Stress-Test & External-Readiness Audit Suite
Author: Prepared for Richard Alan Wise (Nov 19, 2026)

Designed to genuinely try to BREAK the model rather than flatter it:
1. Look-Elsewhere / Numerology Monte Carlo Audit on UCD rational ratios
2. Exact 3D Kelvin-BCC vs Cubic Lattice Dispersion & Directional LIV Anisotropy Test
3. Exact Brillouin-Zone Fermion-Doubling Check (Nielsen-Ninomiya Audit)
4. UCD-Fold v3.0 Sequence-Shuffling Null-Control Test (Real PDB vs Shuffled Decoys)
5. Full 76-File Lean 4 Static & Mathlib-Dependency Readiness Audit
"""

import glob
import json
import math
import os
import re
import numpy as np

OUT_DIR = "/working_dir/c_33c008ea726b7fd9/artifacts/file_generation/ttl=63d/intermediate/stress_test"
os.makedirs(OUT_DIR, exist_ok=True)
rng = np.random.default_rng(2026)

# ---------------------------------------------------------------------------
# TEST 1: LOOK-ELSEWHERE / NUMEROLOGY MONTE CARLO AUDIT
# ---------------------------------------------------------------------------
# Targets: lambda_H = 0.1291, Omega_L = 0.6847, Omega_m = 0.3153, sin2_t13 = 0.02203
# Note: Omega_m = 1 - Omega_L, so there are 3 independent targets here.
targets = [0.1291, 0.6847, 0.02203]
tols = [0.005, 0.005, 0.001]  # ~0.5% to 4.5% relative tolerance

# For a random denominator D in [100, 600], how easily can integers a/D hit a target within tol?
# With ANY numerator a in [1, D-1], resolution is 1/D. At D=504, 1/504 = 0.00198!
# So ANY real number in (0,1) is ALWAYS within 0.00099 of SOME fraction a/504!
p_single_hits = []
for D_test in [168, 504]:
    max_err = 0.5 / D_test
    p_single_hits.append({"denominator": D_test, "guaranteed_max_error_for_ANY_number": max_err})

# Monte Carlo: pick a random integer D in [100, 600] and check fraction of trials where
# ONE fixed denominator D hits all 3 targets within 1% relative error simultaneously
n_trials = 5000
hits_all_3 = 0
for _ in range(n_trials):
    D = int(rng.integers(100, 601))
    ok = True
    for tgt, tol in zip(targets, tols):
        best_err = abs(round(tgt * D) / D - tgt)
        if best_err > tol:
            ok = False
            break
    if ok:
        hits_all_3 += 1
p_look_elsewhere = hits_all_3 / float(n_trials)

# ---------------------------------------------------------------------------
# TEST 2: EXACT 3D KELVIN-BCC vs CUBIC DISPERSION & LORENTZ ANISOTROPY (LIV)
# ---------------------------------------------------------------------------
# Kelvin-BCC scaled displacements (length a_sq = 2, a_hex = sqrt(3))
# Unit cell normalized so lattice spacing a = 1:
# Square neighbors: (+/-1, 0, 0), (0, +/-1, 0), (0, 0, +/-1)  [dist = 1]
# Hex neighbors: (+/-0.5, +/-0.5, +/-0.5)                     [dist = sqrt(3)/2]
SQ_V = np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]], dtype=float)
HEX_V = np.array([
    [0.5,0.5,0.5],[0.5,0.5,-0.5],[0.5,-0.5,0.5],[0.5,-0.5,-0.5],
    [-0.5,0.5,0.5],[-0.5,0.5,-0.5],[-0.5,-0.5,0.5],[-0.5,-0.5,-0.5]
], dtype=float)

# For exact 4th-moment isotropy of the discrete Laplacian L(k) = sum w_e (1 - cos(k.d_e)):
# Expand 1 - cos(k.d) = (k.d)^2/2 - (k.d)^4/24 + (k.d)^6/720.
# For SQ: d_i^2 = 1, d_i^4 = 1; for HEX: d_i^2 = 1/4, d_i^4 = 1/16, d_x^2 d_y^2 = 1/16.
# Isotropy of k^4 term requires sum w_sq * 1 + sum w_hex * (1/16) = 3 * sum w_hex * (1/16)
# -> 2*w_sq + 8*(1/16)*w_hex = 3 * 8*(1/16)*w_hex -> 2*w_sq = 1.0*w_hex -> w_hex = 2*w_sq!
# Let's test BOTH UCD's area/flux weights (w_sq=1/15, w_hex=3/40 -> ratio 9/8) AND exact Laplacian weights (w_hex=2*w_sq)!
def disp_kelvin(k_vec, w_sq, w_hex):
    s = w_sq * np.sum(1.0 - np.cos(SQ_V @ k_vec))
    h = w_hex * np.sum(1.0 - np.cos(HEX_V @ k_vec))
    return float(s + h)

def disp_cubic(k_vec):
    return float(np.sum(1.0 - np.cos(SQ_V @ k_vec)))

dirs_test = {
    "[1,0,0]": np.array([1.0, 0.0, 0.0]),
    "[1,1,0]": np.array([1.0, 1.0, 0.0]) / math.sqrt(2.0),
    "[1,1,1]": np.array([1.0, 1.0, 1.0]) / math.sqrt(3.0),
}

liv_results = {}
k_mag = 0.05  # Low-momentum regime k*a = 0.05
for label, fn in [
    ("Cubic (6-port)", lambda kv: disp_cubic(kv)),
    ("Kelvin-BCC (UCD unit-normal weights 1/15, 3/40)", lambda kv: disp_kelvin(kv, 1.0/15.0, 3.0/40.0)),
    ("Kelvin-BCC (exact Laplacian isotropic weights w_hex=2*w_sq)", lambda kv: disp_kelvin(kv, 1.0/22.0, 2.0/22.0)),
]:
    c_vals = []
    for dname, dvec in dirs_test.items():
        w2 = fn(k_mag * dvec)
        c_eff = math.sqrt(w2) / k_mag
        c_vals.append(c_eff)
    aniso = (max(c_vals) - min(c_vals)) / np.mean(c_vals)
    liv_results[label] = {
        "c_100": c_vals[0], "c_110": c_vals[1], "c_111": c_vals[2],
        "directional_anisotropy_dc_over_c_at_ka_0.05": aniso,
        "anisotropy_order": "O((ka)^4)" if aniso < 1e-7 else "O((ka)^2)",
    }

# ---------------------------------------------------------------------------
# TEST 3: NIELSEN-NINOMIYA FERMION DOUBLING CHECK ON KELVIN-BCC
# ---------------------------------------------------------------------------
# Naive Hermitian Dirac operator D(k) = sum_a w_a * (d_a . gamma) * sin(k . d_a)
# Zero modes occur wherever vector V(k) = sum_a w_a * d_a * sin(k . d_a) = (0, 0, 0).
# Scan high-symmetry points in BCC Brillouin zone (k in [-2*pi, 2*pi]^3):
def dirac_vec_kelvin(k_vec):
    v_sq = (1.0/15.0) * np.sum(SQ_V * np.sin(SQ_V @ k_vec)[:, None], axis=0)
    v_hex = (3.0/40.0) * np.sum(HEX_V * np.sin(HEX_V @ k_vec)[:, None], axis=0)
    return v_sq + v_hex

# Check Gamma=(0,0,0), H=(2pi,0,0), P=(pi,pi,pi), N=(pi,pi,0)
bz_pts = {
    "Gamma (0,0,0)": np.array([0.0, 0.0, 0.0]),
    "H (2pi,0,0)": np.array([2*math.pi, 0.0, 0.0]),
    "P (pi,pi,pi)": np.array([math.pi, math.pi, math.pi]),
    "N (pi,pi,0)": np.array([math.pi, math.pi, 0.0]),
}
doublers_found = []
for name, kp in bz_pts.items():
    norm_v = float(np.linalg.norm(dirac_vec_kelvin(kp)))
    if norm_v < 1e-10:
        doublers_found.append({"point": name, "norm_D_k": norm_v})

# ---------------------------------------------------------------------------
# TEST 4: UCD-FOLD v3.0 SEQUENCE-SHUFFLING NULL-CONTROL TEST
# ---------------------------------------------------------------------------
# Import UCD-Fold v3.0 energy function and test whether real PDB 1UAO (Chignolin)
# scores better than 8 random shuffles of the EXACT SAME 10 amino acids!
import sys
sys.path.insert(0, "/working_dir/c_33c008ea726b7fd9/artifacts/file_generation/ttl=63d/intermediate/ucd_fold_v3")
import ucd_fold_v3_complete as uf3

real_seq = "GYDPETGTWG"
r_real = uf3.run_remc_v3(real_seq, n_sweeps=140, steps_per_sweep=10, seed=101)
real_F = r_real["best_state"]["F"]

shuf_Fs = []
for k in range(8):
    chars = list(real_seq)
    rng.shuffle(chars)
    s_shuf = "".join(chars)
    r_s = uf3.run_remc_v3(s_shuf, n_sweeps=140, steps_per_sweep=10, seed=200 + k)
    shuf_Fs.append(r_s["best_state"]["F"])

z_score_shuf = (real_F - float(np.mean(shuf_Fs))) / (float(np.std(shuf_Fs)) + 1e-9)

# ---------------------------------------------------------------------------
# TEST 5: FULL 76-FILE LEAN 4 STATIC & MATHLIB-DEPENDENCY AUDIT
# ---------------------------------------------------------------------------
lean_files = sorted(glob.glob("/working_dir/c_33c008ea726b7fd9/**/*.lean", recursive=True))
lean_audit = {
    "total_files": len(lean_files),
    "pure_core_no_mathlib": 0,
    "requires_mathlib": 0,
    "files_with_sorry_tactic": 0,
    "files_with_axiom_decl": 0,
    "unbalanced_delimiters": 0,
    "total_theorems_lemmas": 0,
}
for lf in lean_files:
    with open(lf, errors="ignore") as f:
        txt = f.read()
    # Strip block comments /- ... -/ and line comments -- ...
    clean = re.sub(r"/-.*?-/", "", txt, flags=re.S)
    clean = re.sub(r"--.*", "", clean)
    if "import Mathlib" in clean:
        lean_audit["requires_mathlib"] += 1
    else:
        lean_audit["pure_core_no_mathlib"] += 1
    if re.search(r"\bsorry\b", clean):
        lean_audit["files_with_sorry_tactic"] += 1
    if re.search(r"^\s*axiom\b", clean, flags=re.M):
        lean_audit["files_with_axiom_decl"] += 1
    if clean.count("(") != clean.count(")") or clean.count("{") != clean.count("}"):
        lean_audit["unbalanced_delimiters"] += 1
    lean_audit["total_theorems_lemmas"] += len(re.findall(r"^\s*(?:theorem|lemma)\b", clean, flags=re.M))

report = {
    "test1_numerology_look_elsewhere": {
        "resolution_check": p_single_hits,
        "mc_prob_random_denom_hits_3_targets_simultaneously": p_look_elsewhere,
        "verdict": "HIGH RISK OF NUMEROLOGY: Because 1/504 = 0.00198, ANY real number is guaranteed within 0.001 of some fraction a/504, and {:.1f}% of random denominators in [100,600] hit all 3 targets simultaneously! Rational matches MUST be derived dynamically, not selected post-hoc.".format(100 * p_look_elsewhere),
    },
    "test2_kelvin_lorentz_anisotropy": liv_results,
    "test3_fermion_doubling_nielsen_ninomiya": {
        "zero_modes_found_at_high_symmetry_points": doublers_found,
        "count": len(doublers_found),
        "verdict": "CONFIRMED HURDLE: Naive Hermitian Dirac operator on Kelvin-BCC has multiple Brillouin-zone zero modes (fermion doublers at Gamma, H, P, N), confirming the Nielsen-Ninomiya theorem applies and requires Wilson/Ginsparg-Wilson fermions." if len(doublers_found) > 1 else "Single mode",
    },
    "test4_ucd_fold_sequence_shuffling_control": {
        "1UAO_real_F": real_F,
        "shuffled_mean_F": float(np.mean(shuf_Fs)),
        "shuffled_std_F": float(np.std(shuf_Fs)),
        "Z_score_real_vs_shuffled": z_score_shuf,
        "verdict": "PASS: Real sequence folds significantly lower than shuffled decoys" if z_score_shuf < -1.0 else "HONEST LIMITATION: Coarse-grained MJ20+H-bond score does not strongly separate 1UAO from random shuffles of identical composition (Z={:.2f}); all-atom side-chain sterics are needed for sequence specificity.".format(z_score_shuf),
    },
    "test5_lean4_76_file_audit": lean_audit,
}

with open(os.path.join(OUT_DIR, "adversarial_stress_test_report.json"), "w") as f:
    json.dump(report, f, indent=2)

print(json.dumps(report, indent=2))
