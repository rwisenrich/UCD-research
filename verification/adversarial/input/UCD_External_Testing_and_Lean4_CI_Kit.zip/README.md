# UCD External Testing & Lean 4 Verification Kit

This kit contains everything needed to independently test and stress-test the Universal Coherence Dynamics (UCD) models outside this environment:

1. `UCD/` — All 76 pure-core Lean 4 modules (579 theorems/lemmas, 0 Mathlib dependencies, 0 sorry tactics, 0 custom axioms).
2. `lean-toolchain`, `lakefile.toml`, `.github/workflows/lean_ci.yml` — Push this folder to a GitHub repository to run a live external Lean 4 compiler check across all 76 files automatically.
3. `stress_test/ucd_adversarial_stress_test.py` & `stress_test/adversarial_stress_test_report.json` — Reproducible 5-part adversarial stress-test suite (look-elsewhere numerology audit, 3D Kelvin-BCC dispersion & LIV anisotropy, Nielsen-Ninomiya fermion doubling, UCD-Fold sequence-shuffling control, and static Lean 4 audit).
