import Lake
open Lake DSL

package «addressed_calculus_core» where
  version := v!"18.0.0"

@[default_target]
lean_lib «AddressedCalculusCore» where
  roots := #[`AddressedCalculusCore, `ComparatorChallenges]
