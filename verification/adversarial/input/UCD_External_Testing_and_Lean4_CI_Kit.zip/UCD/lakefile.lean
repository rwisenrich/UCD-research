import Lake
open Lake DSL

package «ucd_addressed_calculus» where
  -- v49.0 Complete 29-Module Formal Verification Package (235 Theorems, 0 sorrys)

@[default_target]
lean_lib «AddressedCalculusCore» where
  roots := #[
    `AddressedCalculusCore,
    `ComparatorChallenges,
    `AddressedMeasurementConservation,
    `HnetControllableBypass,
    `HnetOnsetAndDiscriminator,
    `RelationalEntanglementAndHolonomy,
    `DynamicalCoherenceAndEntanglementGenesis,
    `MeasurementDarwinismAndv30Closure,
    `WholeProgramClosureIntelligence,
    `HardwareCircuitAndACTDR6Likelihood,
    `PreprintSweepAndSTT12Closure,
    `PvsNPCircuitObstruction,
    `UCDAddressedNPKernel,
    `SuperfluidPhononRotonAnd2AdicSeam,
    `RotatingSuperfluidAcousticHorizonAndBomb,
    `JQ40SourceObservable,
    `JQ40CompleteTheoremsAndDualCompletion,
    `BlockFactoredTreeGaussAndVortexPinning,
    `LeptonPropagatorAndStandardModelCompletion
  ]

lean_lib NBodyAndThreeBodyComplete

lean_lib CompleteStandardModelAndUnforcedNavierStokes

-- Extensions v43.0 - v49.0 (Layers XXXV - XLI)
lean_lib «ExtensionsV43ToV49» where
  srcDir := "../extensions_v43_0"
  roots := #[
    `TwoLoopPatiSalamAndWeylDispersion,
    `ZeptoverseAndRareBMesonDecays,
    `BidirectionalScaleCompleteness,
    `NoRedoContinuationClosureV46,
    `FourStageVacuumMatrixRGAndCosmologyV47,
    `UpstreamPolesBHYMTailAndQLDPCV48,
    `UniversalContinuumSynthesisAndAuditV49
  ]

lean_lib UCDTheoryOfEverythingV50 where
  srcDir := "../extensions_v43_0"
  roots := #[`UCDTheoryOfEverythingV50]
