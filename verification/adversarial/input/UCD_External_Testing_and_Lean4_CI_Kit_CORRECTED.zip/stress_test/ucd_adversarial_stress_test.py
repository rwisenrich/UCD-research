#!/usr/bin/env python3
"""Portable adversarial regressions for UCD external Lean 4 audit.

The source archive's existing Lean files are not edited. Only the claims that
can be reproduced from the archive itself are evaluated. Optional protein
engine reruns are separate (the folding engine is not bundled here).
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def nearest_error(target: Fraction, denominator: int) -> Fraction:
    k = (target.numerator * denominator) // target.denominator
    return min(abs(target - Fraction(k, denominator)),
               abs(target - Fraction(k + 1, denominator)))


def scan(targets, tolerances):
    winners = [d for d in range(100, 601) if all(
        nearest_error(target, d) <= tol
        for target, tol in zip(targets, tolerances))]
    return {'hits': len(winners), 'denominators': 501,
            'fraction': len(winners)/501,
            'range': [100, 600], 'first_winners': winners[:12]}


def test_look_elsewhere():
    original = scan([Fraction('0.1291'), Fraction('0.6847'), Fraction('0.02203')],
                    [Fraction('0.005'), Fraction('0.005'), Fraction('0.001')])
    strict = scan([Fraction(65,504),Fraction(115,168),Fraction(1,45)],
                  [Fraction('0.001')]*3)
    assert original['hits']==337, original
    assert strict['hits']==225, strict
    return {'original_report_control':original, 'uniform_absolute_0.001_control':strict,
            'note':'Original Monte Carlo 0.6766 is consistent with finite-sample noise around 337/501; the 225/501 control uses different targets and tolerances.',
            'limitation':'A grid match does not dynamically derive the numerator.'}


def bcc_symbol(k,square,hexagon):
    return (2*square*sum(1-math.cos(x) for x in k) +
            8*hexagon*(1-math.prod(math.cos(x/2) for x in k)))


def bcc_spread(t,square,hexagon):
    dirs={'100':(1.,0.,0.),'110':(2**-.5,2**-.5,0.),
          '111':(3**-.5,3**-.5,3**-.5)}
    c=[math.sqrt(bcc_symbol(tuple(t*x for x in vec),square,hexagon))/t for vec in dirs.values()]
    return (max(c)-min(c))/(sum(c)/3),c


def test_dispersion():
    choices={'cubic':(1.,0.),'kelvin_cubature_used_as_links':(1/15,3/40),
             'kelvin_isotropic_scalar_links':(1/22,2/22)}
    out={k:dict(zip(('relative_directional_spread','phase_speeds'),bcc_spread(.05,*v)))
         for k,v in choices.items()}
    assert abs(out['cubic']['relative_directional_spread'] - 6.944597157475057e-5)<1e-9
    assert abs(out['kelvin_cubature_used_as_links']['relative_directional_spread'] - 1.4296988546125927e-5)<1e-9
    assert abs(out['kelvin_isotropic_scalar_links']['relative_directional_spread'] - 1.0850229269843051e-9)<1e-10
    # Fourth-order coefficients: sum_i k_i^4: -(sq/12+hex/48);
    # sum_{i<j}k_i^2*k_j^2: -hex/8, so equality demands hex=2*sq.
    sq, hx=Fraction(1,22),Fraction(2,22)
    assert hx/8 == 2*(sq/12+hx/48)
    out['derived_weight_ratio']='hexagonal scalar-Laplacian link weight = 2 * square link weight'
    out['relative_improvement_vs_cubic']=out['cubic']['relative_directional_spread']/out['kelvin_isotropic_scalar_links']['relative_directional_spread']
    out['scope']='scalar BCC link Laplacian only; preserve separate face-normal cubature weights 1/15 and 3/40'
    return out


def gradient(k,square=Fraction(1,15),hexagon=Fraction(3,40)):
    sq,hx=float(square),float(hexagon)
    return [2*sq*math.sin(k[i]) + 2*hx*math.sin(k[i]/2)*math.prod(math.cos(k[j]/2) for j in range(3) if j!=i)
            for i in range(3)]


def test_naive_fermion_doubling():
    sites={'Gamma':[0.,0.,0.],'H':[2*math.pi,0.,0.],
           'P':[math.pi,math.pi,math.pi], 'N':[math.pi,math.pi,0.]}
    norms={s:math.sqrt(sum(v*v for v in gradient(k))) for s,k in sites.items()}
    assert all(v<1e-12 for v in norms.values()),norms
    return {'high_symmetry_zero_norms':norms,
            'scope':'naive 14-neighbor derivative only; production Wilson/overlap Dirac is a distinct operator, not tested here'}


def test_fold_report():
    file=ROOT/'stress_test'/'adversarial_stress_test_report.json'
    original=json.loads(file.read_text())['test4_ucd_fold_sequence_shuffling_control']
    real=original['1UAO_real_F']
    mean=original['shuffled_mean_F']
    sd=original['shuffled_std_F']
    z=(real-mean)/sd
    assert abs(z-original['Z_score_real_vs_shuffled'])<1e-6
    assert z>-2
    return {'reported_z_reproduced':z,'shuffles':8,'minimum_possible_empirical_one_sided_p':1/9,
            'passes_2sigma':False,'status':'BLOCKED: real folding engine and sequence-level energies are not included in ZIP',
            'note':'Validates serialized statistics only. A protein refolding rerun is not claimed.'}


def noncommented(text):
    # Scan nested Lean block comments, line comments, and quoted strings.
    out=[]; i=0; nesting=0; string=False
    while i<len(text):
        if nesting:
            if text.startswith('/-',i):nesting+=1;i+=2;continue
            if text.startswith('-/',i):nesting-=1;i+=2;continue
            if text[i]=='\n':out.append('\n')
            i+=1;continue
        if text.startswith('/-',i):nesting=1;i+=2;continue
        if not string and text.startswith('--',i):
            j=text.find('\n',i)
            if j<0:break
            out.append('\n');i=j+1;continue
        if text[i]=='"' and (i==0 or text[i-1]!='\\'):string=not string
        if string:
            if text[i]=='\n':out.append('\n')
            else:out.append(' ')
        else:out.append(text[i])
        i+=1
    if nesting or string:raise ValueError('unterminated block comment or string literal')
    return ''.join(out)


def test_lean_inventory():
    root=ROOT/'UCD'
    files=sorted(root.glob('*.lean'))
    assert len(files)==76,len(files)
    config=[p for p in files if p.name in ('lakefile.lean','lean4_addressed_calculus_lakefile.lean')]
    source=[p for p in files if p not in config]
    hashes=defaultdict(list)
    for p in source:hashes[sha256(p.read_bytes()).hexdigest()].append(p.name)
    duplicates=[x for x in hashes.values() if len(x)>1]
    decl=0;unique_decl=0;hazards=[]
    for p in source:
        clean=noncommented(p.read_text())
        n=len(re.findall(r'(?m)^\s*(?:theorem|lemma)\b',clean))
        decl+=n
        if p.name == hashes[sha256(p.read_bytes()).hexdigest()][0]:unique_decl+=n
        for name,pat in [('sorry',r'\bsorry\b'),('admit',r'\badmit\b'),
                         ('axiom',r'(?m)^\s*axiom\b'),('opaque',r'(?m)^\s*opaque\b'),
                         ('Mathlib',r'\bimport\s+Mathlib\b')]:
            if re.search(pat,clean): hazards.append({'file':p.name,'marker':name})
    assert len(source)==74 and len(hashes)==66
    assert decl==579 and unique_decl==519, (decl,unique_decl)
    return {'total_lean_extension_files':len(files),'lake_config_files':len(config),
            'proof_source_files':len(source),'exactly_distinct_proof_bodies':len(hashes),
            'duplicate_source_pairs':duplicates,'theorem_declarations_in_all_sources':decl,
            'theorem_declarations_in_distinct_sources':unique_decl,
            'static_hazards_after_comment_strip':hazards,
            'status':'Static inventory only; live compiler check is separate and mandatory.'}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',default='results/stress_test_report.json')
    a=p.parse_args()
    result={
        'test1_look_elsewhere':test_look_elsewhere(),
        'test2_kelvin_dispersion':test_dispersion(),
        'test3_naive_fermion_doubling':test_naive_fermion_doubling(),
        'test4_protein_sequence_shuffle':test_fold_report(),
        'test5_lean_inventory':test_lean_inventory(),
        'summary':'Completed reproducible mathematical and static-source controls. No live Lean compilation or protein re-fold was executed by this script.'}
    dest=Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:('PASS' if k.startswith('test') else v) for k,v in result.items()},indent=2))
    print('report:',dest)

if __name__=='__main__':main()
