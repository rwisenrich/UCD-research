#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p results/lean_compilation
export LEAN_PATH="$PWD/UCD${LEAN_PATH:+:$LEAN_PATH}"
if ! command -v lean >/dev/null 2>&1; then
  echo 'ERROR: Lean 4 compiler is not installed' >&2
  exit 2
fi
lean --version | tee results/lean_compilation/compiler_version.txt
# Required dependency for ComparatorChallenges.lean.
if ! lean -o UCD/AddressedCalculusCore.olean UCD/AddressedCalculusCore.lean > results/lean_compilation/AddressedCalculusCore.log 2>&1; then
  cat results/lean_compilation/AddressedCalculusCore.log
  echo 'ERROR: prerequisite AddressedCalculusCore.lean did not compile' >&2
  exit 1
fi
pass=0
fail=0
for file in UCD/*.lean; do
  name="$(basename "$file")"
  case "$name" in
    lakefile.lean|lean4_addressed_calculus_lakefile.lean) continue ;;
  esac
  echo "Checking $name"
  if lean "$file" > "results/lean_compilation/${name%.lean}.log" 2>&1; then
    pass=$((pass+1))
  else
    fail=$((fail+1))
    echo "FAIL: $name"
    cat "results/lean_compilation/${name%.lean}.log"
  fi
done
printf 'PROOF_SOURCE_FILES=%s\nCOMPILER_SUCCESSES=%s\nCOMPILER_FAILURES=%s\n' 74 "$pass" "$fail" | tee results/lean_compilation/summary.txt
if [ "$pass" -ne 74 ] || [ "$fail" -ne 0 ]; then exit 1; fi
