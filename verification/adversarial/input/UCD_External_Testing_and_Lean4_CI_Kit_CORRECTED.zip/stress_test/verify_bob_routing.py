#!/usr/bin/env python3
"""Independent, exhaustive 24-element Dic6 partner-routing control.

The old expected Bob sector omitted dependence on the reflection bit e.
This test compares the explicit group product against the corrected formula,
checks antipodal equivalence, and tests the 12-sector bijection.
"""
import json
from pathlib import Path


def dic6_mul(g, h):
    k, e = g
    t, f = h
    return ((k + (-1 if e % 2 else 1) * t + 6 * (e % 2) * (f % 2)) % 12,
            (e + f) % 2)


def dic6_inv(g):
    k, e = g
    if e % 2 == 0:
        return ((12 - (k % 12)) % 12, 0)
    return ((k + 6) % 12, 1)


def sector(g):
    k, e = g
    return 4 * (k % 3) + 2 * (k % 2) + (e % 2)


def expected(g, *, incorrect=False):
    k, e = g
    r = k % 3
    r_b = (-r) % 3 if (incorrect or e % 2 == 1) else r
    return 4 * r_b + 2 * (k % 2) + (1 - e % 2)


def test():
    states = [(k, e) for k in range(12) for e in range(2)]
    wrong = []
    for g in states:
        actual = sector(dic6_mul((0, 1), dic6_inv(g)))
        assert actual == expected(g), (g, actual, expected(g))
        assert sector(g) == sector(((g[0] + 6) % 12, g[1]))
        if actual != expected(g, incorrect=True):
            wrong.append({'g': list(g), 'actual': actual,
                          'old_claim': expected(g, incorrect=True)})
    assert len(wrong) == 8, len(wrong)
    image = {expected((k, e)) for k in range(6) for e in range(2)}
    assert image == set(range(12)), image
    return {
        'group_elements_checked': len(states),
        'old_mapping_mismatches': len(wrong),
        'old_mapping_counterexamples': wrong,
        'corrected_mapping_mismatches': 0,
        'antipodal_sector_tests': len(states),
        'distinct_bob_sector_images': len(image),
        'formula': 'r_B = (-1)^e r mod 3, p_B = p, e_B = 1-e',
        'scope': 'finite Dic6 sector mapping only; no communication-capacity proof'
    }


if __name__ == '__main__':
    report = test()
    out = Path('results/bob_routing_control.json')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k,v in report.items() if k!='old_mapping_counterexamples'}, indent=2))
