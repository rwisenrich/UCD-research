#!/usr/bin/env python3
"""Toy BCC Wilson-overlap reference; not the unbundled full UCD gauge kernel."""
from __future__ import annotations
import itertools
import json
import math
from pathlib import Path
import numpy as np

P1=np.array([[0,1],[1,0]],dtype=complex)
P2=np.array([[0,-1j],[1j,0]],dtype=complex)
P3=np.diag([1,-1]).astype(complex)
Z=np.zeros((2,2),dtype=complex)
GAMMA=[np.block([[Z,-1j*p],[1j*p,Z]]) for p in (P1,P2,P3)]
G5=np.diag([1,1,-1,-1]).astype(complex)
EYE=np.eye(4,dtype=complex)


def derivative(k):
    sq,hx=1/3,2/3
    return [(sq*math.sin(k[i]) + 2*hx*math.sin(k[i]/2)*math.prod(math.cos(k[j]/2) for j in range(3) if i!=j))
            /(sq+hx) for i in range(3)]


def wilson(k):
    sq,hx=1/3,2/3
    return (2*sq*sum(1-math.cos(x) for x in k) + 8*hx*(1-math.prod(math.cos(x/2) for x in k)))/(2*(sq+hx))


def point(k):
    grad=derivative(k)
    w=wilson(k)
    A=(w-1)*EYE+1j*sum((d*g for d,g in zip(grad,GAMMA)),np.zeros((4,4),complex))
    H=G5@A
    assert np.linalg.norm(H-H.conj().T)<1e-10
    vals,vecs=np.linalg.eigh(H)
    if min(abs(vals)) < 1e-10: raise ValueError('Wilson kernel zero; sign is undefined')
    sign=(vecs*np.sign(vals))@vecs.conj().T
    D=.5*(EYE+G5@sign)
    gw=np.linalg.norm(D@G5+G5@D-2*D@G5@D)
    smallest=float(np.min(np.linalg.svd(D,compute_uv=False)))
    return {'naive_gradient_norm':math.sqrt(sum(x*x for x in grad)),
            'overlap_min_singular_value':smallest,'GW_residual':float(gw)}


def main():
    sites={'Gamma':(0.,0.,0.),'H':(2*math.pi,0.,0.),
           'P':(math.pi,math.pi,math.pi),'N':(math.pi,math.pi,0.)}
    out={k:point(v) for k,v in sites.items()}
    assert out['Gamma']['overlap_min_singular_value']<1e-12
    for k in ('H','P','N'):
        assert out[k]['naive_gradient_norm']<1e-12
        assert out[k]['overlap_min_singular_value']>.99
    samples=[-math.pi,-math.pi/2,0,math.pi/2,math.pi]
    max_gw=max(point(ks)['GW_residual'] for ks in itertools.product(samples,repeat=3))
    assert max_gw<1e-10
    result={'points':out,'sample_count':len(samples)**3,'max_GW_residual':max_gw,
            'scope':'Only this explicitly constructed reference Wilson-overlap operator; no full-zone or production-UCD-operator proof.'}
    p=Path('results/overlap_reference.json')
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
