#!/usr/bin/env python3
"""Reproducible paired-composition UCD-Fold decoy experiment.

Requires the actual ucd_fold_v3_complete.py implementation, which is NOT
present in the supplied 76-file CI ZIP. Refuses to fabricate missing results.
"""
from __future__ import annotations
import argparse
import importlib.util
import json
from pathlib import Path
import random
import statistics


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--engine',required=True,help='Path to ucd_fold_v3_complete.py')
    ap.add_argument('--sequence',default='GYDPETGTWG')
    ap.add_argument('--decoys',type=int,default=99)
    ap.add_argument('--seed',type=int,default=2026)
    ap.add_argument('--sweeps',type=int,default=140)
    ap.add_argument('--steps',type=int,default=10)
    ap.add_argument('--output',default='results/fold_decoy_results.json')
    a=ap.parse_args()
    f=Path(a.engine)
    if not f.is_file(): raise SystemExit(f'ENGINE MISSING: {f}. No protein folding run has been performed.')
    if a.decoys<20:raise SystemExit('Require at least 20 decoys for an attainable empirical p < 0.05')
    spec=importlib.util.spec_from_file_location('ucd_fold_v3_complete',str(f))
    if spec is None or spec.loader is None: raise SystemExit('Cannot import requested engine')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod,'run_remc_v3'):raise SystemExit('Engine does not expose run_remc_v3')
    rng=random.Random(a.seed)
    original=a.sequence
    # identical amino-acid composition; reject trivial identical permutations
    sequences=[]
    seen={original}
    while len(sequences)<a.decoys:
        ch=list(original);rng.shuffle(ch);ss=''.join(ch)
        if ss not in seen:
            seen.add(ss);sequences.append(ss)
    native=[];decoy=[]
    for i,s in enumerate(sequences):
        # paired stochastic controls: use identical optimizer seed/budget in each pair
        seed=a.seed+i
        x=mod.run_remc_v3(original,n_sweeps=a.sweeps,steps_per_sweep=a.steps,seed=seed)
        y=mod.run_remc_v3(s,n_sweeps=a.sweeps,steps_per_sweep=a.steps,seed=seed)
        native.append(float(x['best_state']['F']))
        decoy.append(float(y['best_state']['F']))
    deltas=[a-b for a,b in zip(native,decoy)]
    # Paired lower-is-better hypothesis: native beats decoy if delta<0.
    wins=sum(d<0 for d in deltas)
    # conservative sign-test p under null p=1/2. Not calibrated for correlated decoys.
    from math import comb
    pval=sum(comb(len(deltas),j) for j in range(wins,len(deltas)+1))/2**len(deltas)
    report={'source_engine':str(f),'sequence':original,'decoys':a.decoys,
            'optimizer_seed_base':a.seed,'native_mean':statistics.mean(native),
            'decoy_mean':statistics.mean(decoy),'native_wins':wins,
            'paired_sign_p_one_sided':pval,'passes_p_lt_0.05':pval<.05,
            'deltas_native_minus_decoy':deltas,
            'limitations':'Sequence-shuffle test is a necessary control, not a native RMSD/TM-score validation.'}
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='deltas_native_minus_decoy'},indent=2))

if __name__=='__main__':main()
