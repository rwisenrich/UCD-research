# UCD External Adversarial Testing & Lean 4 CI — Corrected Audit Edition

**Purpose.** Independently compile and assess the actual UCD source files. No existing accepted UCD canonical statement was replaced, and no Lean theorem was weakened.

## Corrections relative to the uploaded kit

1. The original `stress_test/ucd_adversarial_stress_test.py` had hard-coded sandbox paths and imported a protein-folding engine not in the ZIP. It therefore raised `ModuleNotFoundError` before generating a fresh report. The unmodified original is preserved as `stress_test/original_adversarial_stress_test_nonportable.py`.
2. The original CI workflow is preserved as `.github/workflows/original_lean_ci_nonportable.yml.txt`. The replacement compiles each of the 74 theorem-source files with the pinned Lean compiler and explicitly generates the `AddressedCalculusCore.olean` dependency needed by `ComparatorChallenges.lean`. It excludes the two unrelated Lake configuration files from the proof-module count. **A local static pass does not imply kernel compilation.**
3. There are 76 files with a `.lean` extension, including **two Lake configuration sources** and **eight duplicate source pairs**. Thus 74 proof-source paths contain 66 distinct bodies, with 579 declarations across the file paths and 519 declarations in distinct bodies. These counts are inventory, not proof scope.
4. Two existing Lean source files contained literal `+/-` inside a `/- ... -/` doc comment, which introduces unintended nested block comments. Only these comment strings were changed to `plus-or-minus`: `TwoLoopPatiSalamAndWeylDispersion.lean` (three occurrences) and `UCDVol3E8D6And66DKrylovTheorems.lean` (one occurrence). No theorem or proof statement in those files was edited.
5. Deterministic enumeration of the original look-elsewhere test (targets 0.1291, 0.6847, 0.02203; tolerances 0.005, 0.005, 0.001) yields **337 / 501 = 67.265%**. The original **67.66%** comes from a 5,000-draw Monte Carlo and is consistent with sampling noise. A distinct, stricter control (exact proposed rational targets, uniform 0.001 absolute tolerance) yields **225 / 501 = 44.91%**. Do not conflate these sampling definitions.
6. The BCC scalar-Laplacian link ratio **w_hex = 2 * w_square** cancels leading fourth-order directional anisotropy. This is not a reason to overwrite face-normal geometric cubature weights (1/15, 3/40) or the gauge/Dirac operator without deriving their respective link measures.
7. The four naive-fermion zero locations are baseline controls, not a no-doubler proof for UCD's full Wilson/overlap gauge kernel. `reference_overlap_check.py` independently verifies Ginsparg–Wilson residuals and lifts the high-symmetry naive zeros for one *explicit reference operator*. Production UCD kernel remains a separate test target.
8. The supplied ZIP has the protein test **summary statistics** but not `ucd_fold_v3_complete.py` nor raw per-decoy energies. The corrected suite validates the reported Z score but does **not** pretend to rerun protein folding. `fold_decoy_protocol.py` can perform paired shuffled controls once the engine is supplied. Eight decoys cannot establish empirical one-sided p < 0.05: the minimum possible value with the add-one rule is 1/9.

### Additional repairs after first live Lean compiler attempt

The actual Lean 4.14.0 compiler on GitHub reported two errors in `AddressedCalculusCore.lean` that could not be discovered by a static keyword scan:

- The field name `rec` collided with Lean's generated structure recursor. It is renamed `record` in the canonical v19 source, its exact alias, and the historical v18 variant; this is an API-name fix, not a change in the mathematical object.
- The abstract `DiffRing` signature lacked the additive and multiplicative commutativity conditions necessary to turn its stated two difference terms into the desired Leibniz identity. Those two conditions are now **explicit structural hypotheses**; the proof is rewritten using them. These additional hypotheses must be reflected in any scientific claim based on the general theorem. The original stronger noncommutative interpretation was not justified.
- The historical v18 source also had unbound `State` type variables; the existing repaired v19 source already contained the correct explicit type binders. The v18 variant now receives the same binder corrections.

The CI compiler runner continues checking other source files after a prerequisite failure so the job provides a complete diagnostic inventory rather than stopping on the first broken source.

## Local/Colab instructions

The five independent audit controls (including the static Lean source inventory) require only Python 3.11+:

`python stress_test/ucd_adversarial_stress_test.py`

Reference overlap check requires NumPy:

`python -m pip install 'numpy>=1.24,<3'`

`python stress_test/reference_overlap_check.py`

For live Lean compilation, install `elan` and the toolchain in `lean-toolchain`, then run:

`bash stress_test/compile_all_lean.sh`

This compiles each of the 74 proof-source **paths** and generates detailed logs. It is not a crosswalk from broad claims to theorem statements; add that separately.

For a properly paired protein null experiment (requires the missing physical folding engine):

`python stress_test/fold_decoy_protocol.py --engine /path/to/ucd_fold_v3_complete.py --decoys 99`

## Scientific status

Exact finite identities, compiler-accepted Lean propositions, tested numerical identities, and experimentally verified physical consequences are **four different evidence levels**. The external GitHub Actions logs determine whether all included Lean files actually compile. Claims about a continuum Yang–Mills mass gap, full Standard Model derivation, or native protein-fold discrimination require separate scope-complete arguments and/or independent measurements.

### Round 3: Narrow, theorem-preserving arithmetic and tactic corrections

External full-source CI found 41 successes and 33 failures in the round-2 ZIP.
Round 3 repairs exactly seven theorem-source files. Integer differences such as
`16 - 17 + 1 = 0` used natural-number subtraction, which truncates below zero;
integer casts restore the actual stated graph Euler and cubic-sign identities.
The fixes to `UCDCompleteTheoryOfEverything.lean` affect the statements' numerical
interpretation (Nat to Int), not the asserted results. The roadmap identity now
uses explicit associative multiplication instead of nonlinear `omega`. Two peptide
parity/nonnegative-square results now use a valid core simplification/nonnegative
product proof instead of unsupported tactics. These repairs are provisional until
confirmed by the external Lean compiler.

False independent numerical assertions, especially `(22*2 - 4*3 - 1 = 19)` in
`UCDTheoryOfEverythingV50.lean` (arithmetic value is 31), are deliberately
**not edited**, to avoid silently changing the physical theory for a green check.
There are other nontrivial unsolved compiler errors, which remain visible in CI.

### Round 4: Nonlinear polynomial proof normalization

Six additional unchanged theorem statements receive syntactic proof-term repairs,
using addition/multiplication distribution or integer arithmetic instead of
unsupported tactics. This pass intentionally leaves false beta-numerator
assertions and complex scientific scope gaps unresolved. Compiler verification
status must be read from the new GitHub Actions run.

### Round 5: Corrected Dic6 Bob-sector routing (substantive finite theorem repair)

GitHub round 4 compiled 49/74 sources (one extra proof repair); five other
unsuccessful proof rewrites were reverted to avoid accumulating speculative code.
Exhaustive independent evaluation of `h = x * g^{-1}` in Dic6 shows the prior
expected sector formula `r_B = -r` (for both reflection bits) is **false in 8 of 24 cases**.
The corrected finite group law is `r_B = (-1)^e r (mod 3)`, `p_B = p`, `e_B=1-e`.
This patch changes the faulty *expected formula* consistently with the already
defined Dic6 product and inverse, and adds `verify_bob_routing.py` to prevent
regression. This is a finite sector mapping theorem, not a capacity proof.
