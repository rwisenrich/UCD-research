# UCD-504 Noisy Driven Subsystem Dynamics

This workbench tests the effective logical/gauge subsystem model

```math
\mathcal C_4 \cong \mathcal L_2\otimes\mathcal G_2
```

under noisy driven pulses

```math
H(t)=u_X(t)X_L\otimes I_G+u_Z(t)Z_L\otimes I_G+\epsilon N(t).
```

It separates strict gate error from subsystem logical error. Strict error compares against `target logical gate ⊗ I_G`; subsystem error compares against `target logical gate ⊗ arbitrary gauge operator`.

## Main interpretation

- Gauge-side noise can change the gauge qubit while leaving the logical qubit intact.
- Logical-side noise is adversarial and corrupts the logical qubit.
- Control amplitude error creates coherent over/under-rotation and needs calibration or composite pulses.
- This is a projected-subsystem noise simulation, not yet a full-504 leakage threshold theorem.

See `noisy_subsystem_aggregate.csv` and `noisy_subsystem_thresholds.csv` for the numerical results.
