from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import json, csv, os, math

OUT='/mnt/data/ucd_504_master_hamiltonian'
summary=json.load(open(os.path.join(OUT,'h504_master_summary.json')))

def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def add_code_para(doc, text):
    p=doc.add_paragraph()
    r=p.add_run(text)
    r.font.name='Courier New'
    r.font.size=Pt(9)
    return p

doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(0.7)
sec.bottom_margin=Inches(0.7)
sec.left_margin=Inches(0.75)
sec.right_margin=Inches(0.75)

styles=doc.styles
styles['Normal'].font.name='Aptos'
styles['Normal'].font.size=Pt(10)
styles['Heading 1'].font.name='Aptos Display'
styles['Heading 2'].font.name='Aptos Display'
styles['Heading 3'].font.name='Aptos Display'

p=doc.add_paragraph()
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('UCD 504-State Master Hamiltonian')
r.bold=True; r.font.size=Pt(18)
p=doc.add_paragraph()
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Full operator definition, representation decomposition, and theorem workbench')
r.italic=True; r.font.size=Pt(11)
p=doc.add_paragraph()
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Generated May 2026')
r.font.size=Pt(9)

doc.add_paragraph('Purpose. This document isolates the 504-state UCD system as its own mathematical object. It does not attempt to connect the 504 system to CKM, PMNS, empirical particle masses, cosmology, or the separate four-sector Schur closure. The goal here is to get the full 504 Hamiltonian written, reproducible, and theorem-ready.')

# Executive results

doc.add_heading('1. Executive result', level=1)
for txt in [
    'The full Hilbert space is H_504 = V7 tensor C^3 tensor C[Dic6], with dimension 7*3*24 = 504.',
    'The recovered Hamiltonian is a seven-term Hermitian Dic6-equivariant finite operator.',
    'The Hamiltonian commutes with the right-regular Dic6 action to machine precision.',
    'The Dic6 isotypic projectors resolve the group factor into four 1D sectors and five 2D sectors.',
    'A universal ring-adjacency cluster gap Delta_ring = 2*kappa*exp(-tau) appears in every Dic6 irrep block.',
    'At the canonical value kappa = 1/10, the gap is Delta_ring = (1/5)*exp(-tau).',
    'Direct center projection kills the ring term, while center-leaf Schur reduction inherits kappa-dependence.'
]:
    doc.add_paragraph(txt, style='List Bullet')

# constants table

doc.add_heading('2. Constants and canonical coefficients', level=1)
tbl=doc.add_table(rows=1, cols=3)
tbl.alignment=WD_TABLE_ALIGNMENT.CENTER
hdr=tbl.rows[0].cells
for i,h in enumerate(['Quantity','Value','Role']):
    hdr[i].text=h; set_cell_shading(hdr[i],'D9EAF7')
rows=[
    ('tau','1/72 = %.15f'%summary['tau'],'Master finite-boundary scale'),
    ('exp(-tau)','%.15f'%summary['exp_minus_tau'],'Global Hamiltonian damping factor'),
    ('kappa','1/10','Leaf-ring coefficient'),
    ('Delta_ring','%.15f'%summary['target_ring_gap'],'Universal ring gap at canonical kappa'),
    ('2 exp(-tau)','%.15f'%summary['expected_d_gap_d_kappa'],'Derivative d Delta / d kappa'),
]
for row in rows:
    cells=tbl.add_row().cells
    for i,v in enumerate(row): cells[i].text=v

# Hamiltonian

doc.add_heading('3. Full 504-state Hamiltonian', level=1)
doc.add_paragraph('The master operator is')
add_code_para(doc, 'H_504 = exp(-tau) * (T1 + eta*T2 + kappa*T3 + gamma*T4 + mu*T5 + nu*T6 + delta*T7).')
doc.add_paragraph('The Hilbert space is')
add_code_para(doc, 'H_504-space = V7 tensor C^3 tensor C[Dic6].')
doc.add_paragraph('The dicyclic group is presented as')
add_code_para(doc, 'Dic6 = <a,x | a^12 = 1, x^2 = a^6, x a x^-1 = a^-1>.')

tbl=doc.add_table(rows=1, cols=3)
tbl.alignment=WD_TABLE_ALIGNMENT.CENTER
hdr=tbl.rows[0].cells
for i,h in enumerate(['Term','Formula','Interpretation']): hdr[i].text=h; set_cell_shading(hdr[i],'E2F0D9')
term_rows=[
('T1','A7 tensor I3 tensor I24','center-leaf star adjacency'),
('T2','I7 tensor XZ tensor I24','Z3 family hopping'),
('T3','R_ring tensor I3 tensor I24','six-leaf ring adjacency'),
('T4','A7 tensor I3 tensor L(a^6)','central parity on the star channel'),
('T5','I7 tensor XZ tensor rho_orient','orientation-coupled family mixing'),
('T6','I7 tensor JZ tensor rho_curr','current/reflection channel'),
('T7','R7 tensor (P0-P2) tensor I24','leaf-family selector/asymmetry'),
]
for row in term_rows:
    cells=tbl.add_row().cells
    for i,v in enumerate(row): cells[i].text=v

add_code_para(doc, 'rho_orient = (L(a) + L(a)^*)/2')
add_code_para(doc, 'rho_curr   = (L(x) + L(x)^*)/2     [current reconstruction used in this workbench]')

# Theorems

doc.add_heading('4. Theorem stack for the 504 system', level=1)

doc.add_heading('Theorem 1: Hermiticity', level=2)
doc.add_paragraph('With the recovered definitions above, every term T_j is Hermitian, hence H_504 is Hermitian.')
add_code_para(doc, 'Computed residual ||H - H^*||_F = %.3e.' % summary['hermiticity_residual'])

doc.add_heading('Theorem 2: Dic6 right-regular symmetry', level=2)
doc.add_paragraph('Because the Dic6-dependent terms use left-regular operators, the Hamiltonian commutes with the right-regular Dic6 action.')
add_code_para(doc, '||[H_504, R(a)]||_F = %.3e' % summary['right_regular_commutator_norm_a'])
add_code_para(doc, '||[H_504, R(x)]||_F = %.3e' % summary['right_regular_commutator_norm_x'])

doc.add_heading('Theorem 3: Irrep block decomposition', level=2)
doc.add_paragraph('The right-regular isotypic projectors decompose C[Dic6] into four one-dimensional sectors and five two-dimensional sectors. On the full 504 space, the block ranks are 21 for each 1D sector and 84 for each 2D sector.')
add_code_para(doc, 'Projector sum residual ||sum P_rho - I24||_F = %.3e.' % summary['projector_sum_residual'])

doc.add_heading('Theorem 4: Universal ring-gap law', level=2)
doc.add_paragraph('In every Dic6 irrep block, the canonical Hamiltonian contains an adjacent cluster gap carried only by T3 = R_ring tensor I3 tensor I24. The gap is')
add_code_para(doc, 'Delta_ring = 2*kappa*exp(-tau).')
doc.add_paragraph('At kappa = 1/10 this becomes')
add_code_para(doc, 'Delta_ring = (1/5)*exp(-tau) = %.15f.' % summary['target_ring_gap'])
add_code_para(doc, 'Max deviation across all 9 irrep blocks = %.3e.' % summary['max_ring_gap_deviation_across_irreps'])
add_code_para(doc, 'Max non-ring Hellmann sensitivity = %.3e.' % summary['max_non_ring_sensitivity_abs'])

# Projection

doc.add_heading('5. Center projection and Schur inheritance', level=1)
doc.add_paragraph('The direct center projection P_c H_504 P_c kills the leaf-ring term because P_c R_ring P_c = 0. Therefore the ring gap does not survive as a direct additive term in the naive center quotient.')
add_code_para(doc, 'max_s || d H_direct_s / d kappa ||_F = %.3e.' % summary['direct_projection_max_dH_dkappa_norm'])
doc.add_paragraph('However, the center-leaf Schur/Feshbach reduction reintroduces kappa-dependence through the eliminated leaf Green function:')
add_code_para(doc, 'H_eff(z) = H_cc - H_cl (H_ll - z I)^(-1) H_lc.')
add_code_para(doc, 'min_s || d H_Schur_s / d kappa ||_F = %.6f.' % summary['schur_projection_min_dH_dkappa_norm'])
add_code_para(doc, 'max_s || d H_Schur_s / d kappa ||_F = %.6f.' % summary['schur_projection_max_dH_dkappa_norm'])

# Status

doc.add_heading('6. Current status and next exact tasks', level=1)
tbl=doc.add_table(rows=1, cols=3)
tbl.alignment=WD_TABLE_ALIGNMENT.CENTER
hdr=tbl.rows[0].cells
for i,h in enumerate(['Layer','Status','Next exact task']): hdr[i].text=h; set_cell_shading(hdr[i],'FFF2CC')
status_rows=[
('Hamiltonian definition','Closed at scaffold level','Decide whether rho_curr is reflection or rotation-current in final canonical convention'),
('Dic6 symmetry','Verified','Write analytic proof from left/right regular commutation'),
('Irrep projectors','Verified','Add proof using character orthogonality'),
('Ring-gap theorem','Machine-precision theorem candidate','Prove the invariant cluster pair analytically'),
('Bosonic 1/2 exp(-tau) gap','Not established','Test only after selector/projection is fixed'),
('Center projection','Verified direct kill / Schur inheritance','Derive closed-form Schur dependence on kappa'),
('Full physical interpretation','Open','Keep separate from the 504 finite theorem until a physical map is derived'),
]
for row in status_rows:
    cells=tbl.add_row().cells
    for i,v in enumerate(row): cells[i].text=v

# reproducibility

doc.add_heading('7. Reproducibility files', level=1)
for fn in ['ucd_504_master_hamiltonian.py','h504_master_operator_spec.json','h504_master_summary.json','irrep_projector_checks.csv','ring_gap_by_irrep.csv','ring_gap_sensitivities.csv','projection_kappa_inheritance.csv','h504_projected_blocks.json']:
    doc.add_paragraph(fn, style='List Bullet')

doc.add_paragraph('Interpretive boundary. This document treats UCD-504 as a finite spectral/operator system. It does not claim that the ring gap is already a measured particle mass, a CKM/PMNS prediction, a gravity derivation, or a completed TOE. Those require additional maps and separate tests.')

path=os.path.join(OUT,'UCD_504_Master_Hamiltonian_and_Theorem_Workbench.docx')
doc.save(path)
print(path)
