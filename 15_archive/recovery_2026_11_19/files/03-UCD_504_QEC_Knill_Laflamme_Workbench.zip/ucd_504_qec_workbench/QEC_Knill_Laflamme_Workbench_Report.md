# UCD-504 Knill-Laflamme QEC Workbench

Tested candidate spectral cluster subspaces against the exact condition P E_a^dagger E_b P = c_ab P.

Canonical ring gap: 0.1972414233487833

| error set | code dim | irrep | energy | KL max residual | max leakage | worst pair |
|---|---:|---|---:|---:|---:|---|
| identity_only | 2 | eps_a=-1,eps_b=1 | 0.902812 | 1.530e-16 | 4.682e-16 | I,I |
| hamiltonian_only | 2 | eps_a=-1,eps_b=1 | 0.902812 | 1.530e-16 | 1.382e-15 | I,I |
| ring_only | 2 | eps_a=-1,eps_b=1 | 0.902812 | 1.630e-16 | 4.506e-15 | T3_leaf_ring,I |
| hamiltonian_terms | 2 | eps_a=-1,eps_b=1 | 0.902812 | 4.840e-16 | 8.679e-01 | T6_current,T7_leaf_family_selector |
| basic_structural | 2 | eps_a=-1,eps_b=1 | 0.902812 | 4.840e-16 | 8.679e-01 | JZ,P0mP2 |

Interpretation: passing identity/Hamiltonian-only tests is expected for spectral clusters. The relevant tests are ring_only, hamiltonian_terms, and basic_structural. These show whether the subspace is a true QEC code for natural UCD errors.


## Full-space verification of best 2D candidate

Best candidate: 1D Dic6 sector eps_a=-1, eps_b=1, cluster 11, energy 0.9028117176982643, code dimension 2.

| error set | KL max residual | max leakage | status |
|---|---:|---:|---|
| ham_terms | 4.052e-15 | 8.679e-01 | PASS |
| basic | 2.004e-15 | 8.679e-01 | PASS |
| local_projectors | 1.167e+00 | 9.644e-01 | FAIL |
| group_unities | 1.199e-15 | 1.330e-15 | PASS |

Conclusion: this is a real restricted Knill-Laflamme hit for collective/symmetry-preserving UCD errors. It fails for individual local projector errors, so it is not yet a universal local-noise QEC code. High leakage for Hamiltonian/basic errors is compatible with KL active correction, but means passive protection alone is not enough for those errors.
