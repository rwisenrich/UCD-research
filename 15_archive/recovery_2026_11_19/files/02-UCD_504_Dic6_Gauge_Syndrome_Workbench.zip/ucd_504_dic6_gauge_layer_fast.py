#!/usr/bin/env python3
from pathlib import Path
import sys, json, csv, math, zipfile
import numpy as np
sys.path.insert(0, '/mnt/data/ucd_504_master_hamiltonian')
import ucd_504_master_hamiltonian as ucd
OUT=Path('/mnt/data/ucd_504_dic6_gauge_layer'); OUT.mkdir(exist_ok=True)
H=ucd.build_H504(); v=ucd.V7_ops(); f=ucd.F3_ops(); I7=v['I7']; I3=f['I3']; I24=np.eye(24,dtype=complex); I504=np.eye(504,dtype=complex)
def lift(A,B,C): return np.kron(np.kron(A,B),C)
def cluster_ranges(vals,tol=1e-8):
    out=[]; i=0; n=len(vals)
    while i<n:
        j=i+1
        while j<n and abs(vals[j]-vals[i])<tol: j+=1
        out.append((i,j,float(np.mean(vals[i:j])))); i=j
    return out
# actions
La=ucd.left_regular((1,0)); Lx=ucd.left_regular((0,1)); La6=ucd.left_regular((6,0))
Ra=ucd.right_regular((1,0)); Rx=ucd.right_regular((0,1)); Ra6=ucd.right_regular((6,0))
rho_orient=0.5*(La+La.conj().T); rho_curr=0.5*(Lx+Lx.conj().T)
error_sets={
 'right_dic6_generators':[('I',I504),('R_a',lift(I7,I3,Ra)),('R_x',lift(I7,I3,Rx)),('R_a6',lift(I7,I3,Ra6))],
 'left_dic6_generators':[('I',I504),('L_a',lift(I7,I3,La)),('L_x',lift(I7,I3,Lx)),('L_a6',lift(I7,I3,La6))],
 'documented_dic6_terms':[('I',I504),('rho_orient',lift(I7,I3,rho_orient)),('rho_curr',lift(I7,I3,rho_curr)),('L_a6',lift(I7,I3,La6))],
}
# lighter local controls for verification: matrix units on factors but avoid all products? we include projectors and generators only
local_struct=[('I',I504),('Pc',lift(v['Pc'],I3,I24)),('R7',lift(v['R7'],I3,I24)),('A7',lift(v['A7'],I3,I24)),('Rring',lift(v['Rring'],I3,I24)),('XZ',lift(I7,f['XZ'],I24)),('JZ',lift(I7,f['JZ'],I24)),('P0mP2',lift(I7,f['P0_minus_P2'],I24))]

def compressed_mats(C,errs):
    EC=[(n,E@C) for n,E in errs]
    mats=[]; names=[]
    for na,EA in EC:
        for nb,EB in EC:
            mats.append(EA.conj().T@EB); names.append((na,nb))
    return names,mats

def span_dim(mats,tol=1e-9):
    M=np.vstack([A.reshape(1,-1) for A in mats])
    S=np.linalg.svd(M,compute_uv=False); thr=max(tol,tol*S[0])
    return int(np.sum(S>thr)), S.tolist()

def commutant_dim(mats,n,tol=1e-8):
    I=np.eye(n,dtype=complex); rows=[]; basis=[]
    for M in mats:
        c=np.trace(M)/n; T=M-c*I; nt=np.linalg.norm(T,'fro')
        if nt<1e-10: continue
        v=(T/nt).reshape(-1); vv=v.copy()
        for q in basis: vv-=np.vdot(q,vv)*q
        if np.linalg.norm(vv)<1e-7: continue
        basis.append(vv/np.linalg.norm(vv))
        rows.append(np.kron(M.T,I)-np.kron(I,M))
    if not rows: return n*n,0,0,[]
    L=np.vstack(rows); S=np.linalg.svd(L,compute_uv=False); thr=max(tol,tol*S[0]); rank=int(np.sum(S>thr)); return n*n-rank,rank,float(thr),S.tolist()

def metrics(C,errs):
    n=C.shape[1]; Id=np.eye(n,dtype=complex); names,mats=compressed_mats(C,errs)
    klmax=0.; klrms=0.; cnt=0
    for M in mats:
        c=np.trace(M)/n; r=float(np.linalg.norm(M-c*Id,'fro')); klmax=max(klmax,r); klrms+=r*r; cnt+=1
    algdim,_=span_dim(mats); cdim,crank,thr,_=commutant_dim(mats,n)
    # for n=4 exact gauge qubit signal: algebra dim 4 and commutant dim 4, or subspace code algebra dim 1 commutant 16
    if n==4:
        classif = 'subspace_code' if algdim==1 and cdim==16 else ('2x2_subsystem_candidate' if algdim<=4 and cdim>=4 else 'no_logical_subsystem_signature')
    else:
        classif = 'possible_subsystem' if cdim>=4 else 'no_logical_subsystem_signature'
    return {'code_dim':n,'kl_max_residual':float(klmax),'kl_rms_residual':float(math.sqrt(klrms/max(cnt,1))),'interaction_algebra_dim':algdim,'commutant_dim':int(cdim),'commutant_rank':int(crank),'subsystem_classification':classif}
# build known code j=1 cluster 14
ir=[x for x in ucd.irreps() if x.name=='j=1'][0]
Hb,B=ucd.irrep_block(H,ucd.isotypic_projector(ir)); vals,vecs=np.linalg.eigh(Hb); clusters=cluster_ranges(vals)
lo,hi,en=clusters[14]
C=B@vecs[:,lo:hi]; C,_=np.linalg.qr(C)
known={'candidate':'j1_cluster14','irrep':'j=1','cluster':14,'energy':en,'dim':hi-lo}
# scan all single dim4 clusters for right/left/documented group signatures only
scan=[]
for ir in ucd.irreps():
    Hb,B=ucd.irrep_block(H,ucd.isotypic_projector(ir)); vals,vecs=np.linalg.eigh(Hb); clusters=cluster_ranges(vals)
    for ci,(lo,hi,en) in enumerate(clusters):
        if hi-lo==4:
            C2=B@vecs[:,lo:hi]; C2,_=np.linalg.qr(C2)
            for setname,errs in error_sets.items():
                row={'irrep_kind':ir.kind,'irrep':ir.name,'cluster':ci,'energy':en,'dim':hi-lo,'error_set':setname}
                row.update(metrics(C2,errs)); scan.append(row)
scan=sorted(scan,key=lambda r:(r['subsystem_classification']!='2x2_subsystem_candidate',r['kl_max_residual'],r['interaction_algebra_dim']))
with open(OUT/'dic6_gauge_dim4_cluster_scan.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(scan[0].keys())); w.writeheader(); w.writerows(scan)
# verify known with local and combined sets (limited)
combined={**error_sets,'local_structural':local_struct,'local_plus_right':local_struct+error_sets['right_dic6_generators'][1:],'local_plus_left':local_struct+error_sets['left_dic6_generators'][1:],'local_plus_documented':local_struct+error_sets['documented_dic6_terms'][1:]}
verify=[]
for setname,errs in combined.items():
    row={**known,'error_set':setname}; row.update(metrics(C,errs)); verify.append(row)
with open(OUT/'dic6_gauge_known_code_verification.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(verify[0].keys())); w.writeheader(); w.writerows(verify)
# compressed products for known for group sets
prod_rows=[]
for setname,errs in error_sets.items():
    names,mats=compressed_mats(C,errs)
    for (a,b),M in zip(names,mats):
        tr=np.trace(M); eig=np.linalg.eigvalsh((M+M.conj().T)/2)
        prod_rows.append({'error_set':setname,'Ea':a,'Eb':b,'trace_real':float(tr.real),'trace_imag':float(tr.imag),'fro_norm':float(np.linalg.norm(M,'fro')),'hermitian_eigs':' '.join(f'{x:.10g}' for x in eig)})
with open(OUT/'dic6_gauge_compressed_products.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(prod_rows[0].keys())); w.writeheader(); w.writerows(prod_rows)
# best rows
best=[]
for setname in error_sets:
    rows=[r for r in scan if r['error_set']==setname]
    best.append(sorted(rows,key=lambda r:(r['subsystem_classification']!='2x2_subsystem_candidate', r['kl_max_residual'], -r['commutant_dim']))[0])
with open(OUT/'dic6_gauge_best_by_error_set.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(best[0].keys())); w.writeheader(); w.writerows(best)
# summary
summary={'dimension':504,'known_code':known,'known_verification':verify,'best_dim4_by_group_error_set':best,'main_result':None}
# derive main result
kv={r['error_set']:r for r in verify}
if kv['right_dic6_generators']['subsystem_classification']=='2x2_subsystem_candidate':
    summary['main_result']='Right-regular Dic6 shifts act as an exact 2x2 gauge/subsystem algebra on the known 4D code candidate. This supports treating the Dic6 right fiber as gauge/syndrome. Left/documented Dic6 errors remain physical unless they also show the same signature.'
else:
    summary['main_result']='No exact right-Dic6 gauge subsystem signature was found for the known 4D code; Dic6 shifts remain the obstruction.'
with open(OUT/'dic6_gauge_summary.json','w') as f: json.dump(summary,f,indent=2)
# report
lines=['| Error set | KL max | Algebra dim | Commutant dim | Classification |','|---|---:|---:|---:|---|']
for r in verify:
    lines.append(f"| {r['error_set']} | {r['kl_max_residual']:.3e} | {r['interaction_algebra_dim']} | {r['commutant_dim']} | {r['subsystem_classification']} |")
report=f"""# UCD-504 Dic6 Gauge/Syndrome Layer Workbench

## Purpose

The previous QEC pass found a 4D spectral code candidate that corrected V7/F3-local errors. The remaining obstruction was Dic6-fiber shift errors. This pass tests whether Dic6 shifts can be interpreted as gauge/subsystem errors rather than logical errors.

The subsystem condition tested is the operator-QEC signature that the compressed interaction algebra generated by `P E_a^dagger E_b P` acts on a gauge factor while leaving a logical factor invariant. For a 4D code, a 2 logical x 2 gauge split is indicated by interaction algebra dimension <= 4 and commutant dimension >= 4.

## Known code candidate

- Irrep: j=1
- Spectral cluster: 14
- Energy: {en}
- Dimension: {hi-lo}

## Verification table

""" + "\n".join(lines) + """

## Interpretation

Right-regular Dic6 shifts are the natural gauge-fiber candidates because H504 commutes with the right-regular Dic6 action. Left-regular/documented Dic6 operators are part of the Hamiltonian dynamics, so they may remain physical errors rather than gauge errors.

See the CSV files for the full dim-4 cluster scan and compressed product spectra.
"""
(OUT/'Dic6_Gauge_Syndrome_Workbench_Report.md').write_text(report)
# zip
zip_path=Path('/mnt/data/UCD_504_Dic6_Gauge_Syndrome_Workbench.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(Path('/mnt/data/ucd_504_dic6_gauge_layer_fast.py'),'ucd_504_dic6_gauge_layer_fast.py')
    for p in OUT.iterdir(): z.write(p,p.relative_to(OUT.parent))
print(json.dumps(summary,indent=2)[:5000]); print(zip_path)
