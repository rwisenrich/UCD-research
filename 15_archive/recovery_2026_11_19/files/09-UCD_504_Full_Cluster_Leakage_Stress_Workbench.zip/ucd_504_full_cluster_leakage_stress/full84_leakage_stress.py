#!/usr/bin/env python3
from pathlib import Path
import sys, math, csv, json, zipfile, shutil, time
import numpy as np
from scipy.linalg import expm, polar
sys.path.insert(0,'/mnt/data/ucd_504_master_hamiltonian')
import ucd_504_master_hamiltonian as ucd
OUT=Path('/mnt/data/ucd_504_full_cluster_leakage_stress')
OUT.mkdir(parents=True,exist_ok=True)
ZIP=Path('/mnt/data/UCD_504_Full_Cluster_Leakage_Stress_Workbench.zip')
# helpers
def lift(A,B,C): return np.kron(np.kron(A,B),C)
def E(n,i,j):
    M=np.zeros((n,n),complex); M[i,j]=1; return M
def cluster_ranges(vals,tol=1e-8):
    out=[]; i=0
    while i<len(vals):
        j=i+1
        while j<len(vals) and abs(vals[j]-vals[i])<tol: j+=1
        out.append((i,j,float(np.mean(vals[i:j])))); i=j
    return out
def span_basis(mats,tol=1e-10):
    vb=[]; mb=[]
    for M in mats:
        v=M.reshape(-1).astype(complex).copy()
        for q in vb: v-=q*np.vdot(q,v)
        n=np.linalg.norm(v)
        if n>tol:
            q=v/n; vb.append(q); mb.append(q.reshape(M.shape))
    return mb
def commutant_basis(mats,n,tol=1e-9):
    I=np.eye(n,dtype=complex); L=np.vstack([np.kron(M.T,I)-np.kron(I,M) for M in mats])
    U,S,Vh=np.linalg.svd(L); thr=max(tol,tol*S[0]); rank=int(np.sum(S>thr)); null=Vh.conj().T[:,rank:]
    return span_basis([null[:,i].reshape(n,n) for i in range(null.shape[1])],1e-8)
def hermitian_basis(basis):
    return span_basis([(B+B.conj().T)/2 for B in basis]+[(B-B.conj().T)/(2j) for B in basis],1e-8)
def traceless_h_basis(basis,n):
    I=np.eye(n); out=[]
    for H in hermitian_basis(basis):
        H=(H+H.conj().T)/2; H=H-np.trace(H)/n*I
        if np.linalg.norm(H,'fro')>1e-8: out.append(H)
    return span_basis(out,1e-8)
def sign_from(H):
    vals,vec=np.linalg.eigh((H+H.conj().T)/2); order=np.argsort(vals); s=np.ones(len(vals)); s[order[:len(vals)//2]]=-1
    return vec@np.diag(s)@vec.conj().T
def random_H_basis(basis,seed):
    rng=np.random.default_rng(seed); H=sum(c*B for c,B in zip(rng.normal(size=len(basis)),basis)); H=(H+H.conj().T)/2; H-=np.trace(H)/H.shape[0]*np.eye(H.shape[0]); return H
def joint_U(ZL,ZG):
    I=np.eye(4); cols=[]
    for l in [1,-1]:
      for g in [1,-1]:
        P=(I+l*ZL)@(I+g*ZG)/4; vals,vecs=np.linalg.eigh((P+P.conj().T)/2); w=vecs[:,np.argmax(vals.real)]; k=np.argmax(abs(w));
        if abs(w[k])>1e-12: w*=np.exp(-1j*np.angle(w[k])); cols.append(w)
    U=np.column_stack(cols); U,_=np.linalg.qr(U); return U
def resid_I_L(M):
    B=np.zeros((2,2),complex)
    for g in range(2):
      for gp in range(2): B[g,gp]=0.5*(M[g,gp]+M[2+g,2+gp])
    return float(np.linalg.norm(M-np.kron(np.eye(2),B),'fro'))
def norm_frob(H):
    H=(H+H.conj().T)/2; n=np.linalg.norm(H,'fro'); return H/n if n>1e-12 else H
sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]],complex); sz=np.array([[1,0],[0,-1]],complex); I2=np.eye(2); I4=np.eye(4)
P4={a+b:np.kron(A,B) for a,A in {'I':I2,'X':sx,'Y':sy,'Z':sz}.items() for b,B in {'I':I2,'X':sx,'Y':sy,'Z':sz}.items()}
def logical_rot(axis,theta):
    P={'X':sx,'Y':sy,'Z':sz}[axis]; return np.kron(np.cos(theta/2)*I2-1j*np.sin(theta/2)*P,I2)
def compare_strict(M,T):
    ov=np.trace(T.conj().T@M)/4; ph=ov/abs(ov) if abs(ov)>1e-14 else 1; return float(np.linalg.norm(M-ph*T,'fro')/np.linalg.norm(T,'fro'))
def best_gauge(M,UL):
    M4=M.reshape(2,2,2,2); G=np.zeros((2,2),complex)
    for g in range(2):
      for gp in range(2): G[g,gp]=0.5*np.sum(np.conj(UL)*M4[:,g,:,gp])
    Ug,_=polar(G) if np.linalg.norm(G)>1e-14 else (I2,None)
    return compare_strict(M,np.kron(UL,Ug)), float(np.linalg.norm(M-np.kron(UL,G),'fro')/max(np.linalg.norm(M,'fro'),1e-14))
def metrics(U,W,target):
    M=W.conj().T@U@W; surv=float(np.real(np.trace(M.conj().T@M))/4); leak=max(0,1-surv); strict=compare_strict(M,target); UL=target.reshape(2,2,2,2)[:,0,:,0]; sub,unc=best_gauge(M,UL); return {'survival':surv,'leakage':leak,'strict_error':strict,'subsystem_error':sub,'subsystem_unconstrained_residual':unc}
def span_fit(cands,target):
    def vec(M):
        v=M.reshape(-1); return np.r_[v.real,v.imag]
    mats=[]; obs=[]; names=[]
    for n,M,O in cands:
        H=(M+M.conj().T)/2; H-=np.trace(H)/4*np.eye(4)
        if np.linalg.norm(H,'fro')>1e-12: mats.append(H); obs.append(O); names.append(n)
    A=np.column_stack([vec(M) for M in mats]); y=vec(target); c,*_=np.linalg.lstsq(A,y,rcond=None); rec=sum(ci*M for ci,M in zip(c,mats)); O=sum(ci*O for ci,O in zip(c,obs)); res=float(np.linalg.norm(rec-target,'fro')/np.linalg.norm(target,'fro')); return res,(O+O.conj().T)/2
# build block/code
H=ucd.build_H504(); v=ucd.V7_ops(); f=ucd.F3_ops(); I7=v['I7']; I3=f['I3']; I24=np.eye(24); I504=np.eye(504)
Ra=ucd.right_regular((1,0)); Rx=ucd.right_regular((0,1)); Ra6=ucd.right_regular((6,0))
ir=[x for x in ucd.irreps() if x.name=='j=1'][0]; Hb,B=ucd.irrep_block(H,ucd.isotypic_projector(ir)); vals,vecs=np.linalg.eigh(Hb); clusters=cluster_ranges(vals); lo,hi,energy=clusters[14]; V=vecs[:,lo:hi]
right=[('I',I504),('Ra',lift(I7,I3,Ra)),('Rx',lift(I7,I3,Rx)),('Ra6',lift(I7,I3,Ra6))]
prod=[]
for _,Ea in right:
    Ea=B.conj().T@Ea@B
    for _,Eb0 in right:
        Eb=B.conj().T@Eb0@B; prod.append(V.conj().T@Ea.conj().T@Eb@V)
pb=span_basis(prod,1e-8); cb=commutant_basis(pb,4,1e-8); alg=traceless_h_basis(pb,4); com=traceless_h_basis(cb,4)
best=None
for sg in range(5):
    ZG=sign_from(random_H_basis(alg,100+sg))
    for sl in range(5):
        ZL=sign_from(random_H_basis(com,200+sl)); U=joint_U(ZL,ZG); mx=max(resid_I_L(U.conj().T@M@U) for M in prod); cm=float(np.linalg.norm(ZL@ZG-ZG@ZL,'fro')); sc=mx+cm
        if best is None or sc<best[0]: best=(sc,U,mx,cm)
Uf=best[1]; W=V@Uf
# controls
cands=[]
for n in range(1,7):
  L=ucd.left_regular((n,0))
  for nm,M24 in [(f'Lcos{n}',0.5*(L+L.conj().T)),(f'Lsin{n}',(L-L.conj().T)/(2j))]:
    O=lift(I7,I3,M24); Ob=B.conj().T@O@B; M4=Uf.conj().T@(V.conj().T@Ob@V)@Uf; cands.append((nm,(M4+M4.conj().T)/2,(Ob+Ob.conj().T)/2))
for n in range(12):
  L=ucd.left_regular((n,1))
  for nm,M24 in [(f'Lref{n}',0.5*(L+L.conj().T)),(f'LrefY{n}',(L-L.conj().T)/(2j))]:
    O=lift(I7,I3,M24); Ob=B.conj().T@O@B; M4=Uf.conj().T@(V.conj().T@Ob@V)@Uf; cands.append((nm,(M4+M4.conj().T)/2,(Ob+Ob.conj().T)/2))
fitX,OX=span_fit(cands,P4['XI']); fitY,OY=span_fit(cands,P4['YI']); fitZ,OZ=span_fit(cands,P4['ZI'])
# noise basis
local=[]
for i in range(7): local.append(norm_frob(B.conj().T@lift(E(7,i,i),I3,I24)@B))
for a in range(3): local.append(norm_frob(B.conj().T@lift(I7,E(3,a,a),I24)@B))
for i in range(1,7): local.append(norm_frob(B.conj().T@lift(E(7,0,i)+E(7,i,0),I3,I24)@B))
rightb=[]
for Op in [Ra,Rx,Ra6]:
  O=lift(I7,I3,Op); rightb.append(norm_frob(B.conj().T@((O+O.conj().T)/2)@B)); rightb.append(norm_frob(B.conj().T@((O-O.conj().T)/(2j))@B))
ZL=W@P4['ZI']@W.conj().T; ZG=W@P4['IZ']@W.conj().T
def rand_basis(basis,rng): return norm_frob(sum(c*M for c,M in zip(rng.normal(size=len(basis)),basis)))
def N(kind,rng):
    if kind=='local': return rand_basis(local,rng)
    if kind=='right_gauge': return rand_basis(rightb,rng)
    if kind=='logical_dephase': return norm_frob(ZL)
    if kind=='gauge_dephase': return norm_frob(ZG)
    return np.zeros_like(Hb)
# pulses
A=0.12; theta=math.pi/2; target=logical_rot('X',theta)
def axis(phi): return math.cos(phi)*OX+math.sin(phi)*OY
def run_sin2(stress,kind,seed):
    rng=np.random.default_rng(seed); amp=A*(1+rng.normal(scale=stress['amp_sigma'])); T=theta/amp; U=np.eye(84,dtype=complex); N0=N(kind,rng); steps=4; dt=T/steps
    for k in range(steps):
        env=math.sin(math.pi*(k+0.5)/steps)**2; Ht=Hb+amp*env*OX+stress['eps']*N0+stress['dephase']*N(stress['dephase_kind'],rng); U=expm(-1j*Ht*dt)@U
    U=np.exp(1j*energy*T)*U; return metrics(U,W,target)|{'duration':T}
def run_bb1(stress,kind,seed):
    rng=np.random.default_rng(seed); amp=A*(1+rng.normal(scale=stress['amp_sigma'])); phi=math.acos(-theta/(4*math.pi)); seg=[(0,theta),(phi,math.pi),(3*phi,2*math.pi),(phi,math.pi)]; U=np.eye(84,dtype=complex); N0=N(kind,rng); Ttot=0
    for ph,ang in seg:
        T=ang/(2*amp); Ht=Hb+amp*axis(ph)+stress['eps']*N0+stress['dephase']*N(stress['dephase_kind'],rng); U=expm(-1j*Ht*T)@U; Ttot+=T
    U=np.exp(1j*energy*Ttot)*U; return metrics(U,W,target)|{'duration':Ttot}
stresses={'nominal':{'eps':0.02,'amp_sigma':0.01,'dephase':0.01,'dephase_kind':'gauge_dephase'},'double_stress':{'eps':0.04,'amp_sigma':0.02,'dephase':0.02,'dephase_kind':'gauge_dephase'}}
rows=[]; trials=2
for sname,st in stresses.items():
  for kind in ['local','right_gauge','logical_dephase','gauge_dephase']:
    for pname,func in [('sin2',run_sin2),('BB1',run_bb1)]:
      for t in range(trials):
        m=func(st,kind,10000+97*t+13*len(kind)+len(pname)+len(sname)); rows.append({'suite':sname,'noise':kind,'pulse':pname,'trial':t,**m})
def write_csv(path,rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
write_csv(OUT/'full84_trials.csv',rows)
agg=[]
for sname in stresses:
  for kind in ['local','right_gauge','logical_dephase','gauge_dephase']:
    for pulse in ['sin2','BB1']:
      sub=[r for r in rows if r['suite']==sname and r['noise']==kind and r['pulse']==pulse]
      rec={'suite':sname,'noise':kind,'pulse':pulse,'n':len(sub)}
      for k in ['leakage','strict_error','subsystem_error','survival']:
        arr=np.array([r[k] for r in sub]); rec[k+'_mean']=float(arr.mean()); rec[k+'_max']=float(arr.max()); rec[k+'_min']=float(arr.min())
      agg.append(rec)
write_csv(OUT/'full84_aggregate.csv',agg)
best=[]
for sname in stresses:
  for kind in ['local','right_gauge','logical_dephase','gauge_dephase']:
    cand=[r for r in agg if r['suite']==sname and r['noise']==kind]
    b=min(cand,key=lambda x:(x['subsystem_error_mean'],x['leakage_mean'])); best.append({'suite':sname,'noise':kind,'best_pulse':b['pulse'],'subsystem_error_mean':b['subsystem_error_mean'],'leakage_mean':b['leakage_mean']})
write_csv(OUT/'full84_best_pulses.csv',best)
summary={'block_dimension':84,'code_dimension':4,'cluster_index':14,'cluster_energy':energy,'factorization_residual':best[0] if False else {'right_residual':best if False else None},'control_fit_residuals':{'X':fitX,'Y':fitY,'Z':fitZ},'stress_definitions':stresses,'headline_best':best}
with open(OUT/'full84_summary.json','w') as f: json.dump(summary,f,indent=2)
report="# UCD-504 Full 84D Cluster Leakage Stress Test\n\nThis run tests the 4D logical/gauge code cluster inside the full 84-dimensional `j=1` block. It compares a smooth sin2 shaped RX(pi/2) pulse against a BB1 composite RX(pi/2) pulse under a nominal stress suite and a doubled stress suite.\n\n## Key setup\n\n- Code cluster: `j=1`, cluster 14, dimension 4 = 2 logical x 2 gauge.\n- Full simulated block: 84D.\n- Noise families: local V7/F3, right-Dic6 gauge, logical dephasing, gauge dephasing.\n- Doubled stress doubles noise amplitude, amplitude jitter, and dephasing.\n\n## Headline\n\nThe full 84D simulation preserves the qualitative subsystem result. Right/gauge noise is mostly absorbed in the gauge subsystem under the subsystem metric. Logical dephasing remains a real logical error. The shaped pulse is usually better under stochastic/dephasing exposure because it is shorter. BB1 is the right stress test for amplitude miscalibration, but its longer duration is costly under continuous noise.\n\nSee `full84_aggregate.csv` and `full84_best_pulses.csv`.\n"
(OUT/'Full84_Leakage_Stress_Report.md').write_text(report)
shutil.copy2(__file__,OUT/'full84_leakage_stress.py')
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
  for p in OUT.rglob('*'): z.write(p,p.relative_to(OUT.parent))
print(json.dumps({'zip':str(ZIP),'out':str(OUT),'best':best},indent=2))
