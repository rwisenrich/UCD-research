# UCD-504 Full 84D Cluster Leakage Stress Test

This run tests the 4D logical/gauge code cluster inside the full 84-dimensional `j=1` block. It compares a smooth sin2 shaped RX(pi/2) pulse against a BB1 composite RX(pi/2) pulse under a nominal stress suite and a doubled stress suite.

## Key setup

- Code cluster: `j=1`, cluster 14, dimension 4 = 2 logical x 2 gauge.
- Full simulated block: 84D.
- Noise families: local V7/F3, right-Dic6 gauge, logical dephasing, gauge dephasing.
- Doubled stress doubles noise amplitude, amplitude jitter, and dephasing.

## Headline

The full 84D simulation preserves the qualitative subsystem result. Right/gauge noise is mostly absorbed in the gauge subsystem under the subsystem metric. Logical dephasing remains a real logical error. The shaped pulse is usually better under stochastic/dephasing exposure because it is shorter. BB1 is the right stress test for amplitude miscalibration, but its longer duration is costly under continuous noise.

See `full84_aggregate.csv` and `full84_best_pulses.csv`.
