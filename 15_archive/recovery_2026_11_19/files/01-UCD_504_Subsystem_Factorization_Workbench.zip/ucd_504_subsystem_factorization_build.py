#!/usr/bin/env python3
from pathlib import Path
import sys, json, csv, math, zipfile
import numpy as np

sys.path.insert(0, '/mnt/data/ucd_504_master_hamiltonian')
import ucd_504_master_hamiltonian as ucd

OUT = Path('/mnt/data/ucd_504_subsystem_factorization')
OUT.mkdir(exist_ok=True)

# ---------- helpers ----------
def lift(A,B,C):
    return np.kron(np.kron(A,B),C)

def cluster_ranges(vals,tol=1e-8):
    vals = np.asarray(vals)
    out=[]; i=0; n=len(vals)
    while i<n:
        j=i+1
        while j<n and abs(vals[j]-vals[i])<tol:
            j+=1
        out.append((i,j,float(np.mean(vals[i:j]))))
        i=j
    return out

def orthonormalize_columns(A, tol=1e-10):
    Q=[]
    for k in range(A.shape[1]):
        v=A[:,k].astype(complex).copy()
        for q in Q:
            v -= q*np.vdot(q,v)
        n=np.linalg.norm(v)
        if n>tol:
            Q.append(v/n)
    if not Q:
        return np.zeros((A.shape[0],0),complex)
    return np.column_stack(Q)

def span_basis(mats, tol=1e-10):
    # Orthonormal basis in Frobenius inner product from input matrices
    vec_basis=[]; mat_basis=[]
    for M in mats:
        v=M.reshape(-1).astype(complex).copy()
        for q in vec_basis:
            v -= q*np.vdot(q,v)
        n=np.linalg.norm(v)
        if n>tol:
            q=v/n
            vec_basis.append(q)
            mat_basis.append(q.reshape(M.shape))
    return mat_basis

def fit_residual_to_span(M, basis):
    v=M.reshape(-1).astype(complex)
    rec=np.zeros_like(v)
    for B in basis:
        b=B.reshape(-1)
        rec += b*np.vdot(b,v)
    return float(np.linalg.norm(v-rec)/max(np.linalg.norm(v),1e-15))

def commutant_basis(mats, n, tol=1e-9):
    # Solve [X,M]=0 for all M. Vectorization: vec(XM-MX) = (M.T kron I - I kron M) vec(X)
    I=np.eye(n,dtype=complex)
    rows=[]
    for M in mats:
        rows.append(np.kron(M.T,I)-np.kron(I,M))
    L=np.vstack(rows)
    U,S,Vh=np.linalg.svd(L)
    thr=max(tol, tol*S[0] if len(S) else tol)
    rank=int(np.sum(S>thr))
    null=Vh.conj().T[:,rank:]
    mats_null=[null[:,i].reshape(n,n) for i in range(null.shape[1])]
    return span_basis(mats_null, tol=1e-8), S.tolist(), rank, thr

def hermitian_basis_from_span(basis, tol=1e-8):
    candidates=[]
    for B in basis:
        candidates.append((B+B.conj().T)/2)
        candidates.append((B-B.conj().T)/(2j))
    # remove scalar identity component? Return full Hermitian basis first
    return span_basis(candidates, tol=tol)

def traceless_hermitian_basis(basis, n, tol=1e-8):
    I=np.eye(n,dtype=complex)
    outs=[]
    for B in hermitian_basis_from_span(basis,tol=tol):
        H=(B+B.conj().T)/2
        H=H-(np.trace(H)/n)*I
        if np.linalg.norm(H,'fro')>tol:
            outs.append(H)
    return span_basis(outs,tol=tol)

def random_hermitian_from_basis(basis, seed=0):
    rng=np.random.default_rng(seed)
    coeffs=rng.normal(size=len(basis))
    H=sum(c*B for c,B in zip(coeffs,basis))
    H=(H+H.conj().T)/2
    H=H-(np.trace(H)/H.shape[0])*np.eye(H.shape[0])
    return H

def sign_operator_from_hermitian(H):
    H=(H+H.conj().T)/2
    vals,vecs=np.linalg.eigh(H)
    # split two low and two high eigenvalues
    order=np.argsort(vals)
    signs=np.zeros(len(vals))
    signs[order[:len(vals)//2]]=-1.0
    signs[order[len(vals)//2:]]=+1.0
    Z=vecs@np.diag(signs)@vecs.conj().T
    return (Z+Z.conj().T)/2, vals.tolist()

def joint_factor_unitary(ZL,ZG):
    # columns ordered |L=+ G=+>, |L=+ G=->, |L=- G=+>, |L=- G=->
    I=np.eye(4,dtype=complex)
    cols=[]; labels=[]
    for l in [+1,-1]:
        for g in [+1,-1]:
            P=(I+l*ZL)@(I+g*ZG)/4
            # choose dominant eigenvector of rank-1 projector
            vals,vecs=np.linalg.eigh((P+P.conj().T)/2)
            idx=np.argmax(vals.real)
            v=vecs[:,idx]
            # deterministic phase: make largest component real positive
            k=np.argmax(np.abs(v))
            if abs(v[k])>1e-12:
                v=v*np.exp(-1j*np.angle(v[k]))
            cols.append(v)
            labels.append((l,g,float(vals[idx].real)))
    U=np.column_stack(cols)
    # QR polish
    U,_=np.linalg.qr(U)
    return U, labels

def partial_trace_logical(M4):
    # ordering: rows/cols index = L*2+G with L=0,1 and G=0,1
    B=np.zeros((2,2),complex)
    for g in range(2):
        for gp in range(2):
            B[g,gp]=0.5*(M4[0*2+g,0*2+gp]+M4[1*2+g,1*2+gp])
    return B

def residual_I_logical_tensor(M4):
    B=partial_trace_logical(M4)
    rec=np.kron(np.eye(2),B)
    return float(np.linalg.norm(M4-rec,'fro'))

def pauli_metrics(X,Y,Z):
    I=np.eye(X.shape[0],dtype=complex)
    return {
        'X_herm':float(np.linalg.norm(X-X.conj().T,'fro')),
        'Y_herm':float(np.linalg.norm(Y-Y.conj().T,'fro')),
        'Z_herm':float(np.linalg.norm(Z-Z.conj().T,'fro')),
        'X2_I':float(np.linalg.norm(X@X-I,'fro')),
        'Y2_I':float(np.linalg.norm(Y@Y-I,'fro')),
        'Z2_I':float(np.linalg.norm(Z@Z-I,'fro')),
        'XY_iZ':float(np.linalg.norm(X@Y-1j*Z,'fro')),
        'YZ_iX':float(np.linalg.norm(Y@Z-1j*X,'fro')),
        'ZX_iY':float(np.linalg.norm(Z@X-1j*Y,'fro')),
        'anti_XZ':float(np.linalg.norm(X@Z+Z@X,'fro')),
        'comm_XY_2iZ':float(np.linalg.norm(X@Y-Y@X-2j*Z,'fro')),
    }

# ---------- build H and code candidate ----------
H=ucd.build_H504()
v=ucd.V7_ops(); f=ucd.F3_ops()
I7=v['I7']; I3=f['I3']; I24=np.eye(24,dtype=complex); I504=np.eye(504,dtype=complex)

La=ucd.left_regular((1,0)); Lx=ucd.left_regular((0,1)); La6=ucd.left_regular((6,0))
Ra=ucd.right_regular((1,0)); Rx=ucd.right_regular((0,1)); Ra6=ucd.right_regular((6,0))

# Known best code: j=1, cluster 14 from previous scan
ir=[x for x in ucd.irreps() if x.name=='j=1'][0]
Hb,B=ucd.irrep_block(H,ucd.isotypic_projector(ir))
vals,vecs=np.linalg.eigh(Hb)
clusters=cluster_ranges(vals)
cluster_index=14
lo,hi,energy=clusters[cluster_index]
C=B@vecs[:,lo:hi]
C,_=np.linalg.qr(C)
code_dim=C.shape[1]

# errors on right Dic6 generators
right_errors=[('I',I504),('R_a',lift(I7,I3,Ra)),('R_x',lift(I7,I3,Rx)),('R_a6',lift(I7,I3,Ra6))]
left_errors=[('I',I504),('L_a',lift(I7,I3,La)),('L_x',lift(I7,I3,Lx)),('L_a6',lift(I7,I3,La6))]
local_errors=[('I',I504),('Pc',lift(v['Pc'],I3,I24)),('R7',lift(v['R7'],I3,I24)),('A7',lift(v['A7'],I3,I24)),('Rring',lift(v['Rring'],I3,I24)),('XZ',lift(I7,f['XZ'],I24)),('JZ',lift(I7,f['JZ'],I24)),('P0mP2',lift(I7,f['P0_minus_P2'],I24))]

# compressed products for right errors: C^dag Ea^dag Eb C
prod_names=[]; prod_mats=[]
for na,Ea in right_errors:
    for nb,Eb in right_errors:
        prod_names.append((na,nb))
        prod_mats.append(C.conj().T@Ea.conj().T@Eb@C)
prod_basis=span_basis(prod_mats,tol=1e-8)
comm_basis, svals, crank, cthr = commutant_basis(prod_basis, code_dim, tol=1e-8)
alg_herm_tr=traceless_hermitian_basis(prod_basis,code_dim,tol=1e-8)
com_herm_tr=traceless_hermitian_basis(comm_basis,code_dim,tol=1e-8)

# Construct gauge Z from interaction algebra, logical Z from commutant
# Use deterministic random seed and retry if bad eigen split.
best=None
for seed_g in range(20):
    Hg=random_hermitian_from_basis(alg_herm_tr,seed=100+seed_g)
    ZG,vg=sign_operator_from_hermitian(Hg)
    for seed_l in range(20):
        Hl=random_hermitian_from_basis(com_herm_tr,seed=200+seed_l)
        ZL,vl=sign_operator_from_hermitian(Hl)
        comm=float(np.linalg.norm(ZL@ZG-ZG@ZL,'fro'))
        U,labels=joint_factor_unitary(ZL,ZG)
        # Test I_L tensor residual for products in this factorization
        maxres=max(residual_I_logical_tensor(U.conj().T@M@U) for M in prod_mats)
        score=comm+maxres
        if best is None or score<best[0]:
            best=(score,seed_g,seed_l,ZG,ZL,U,labels,maxres,comm,vg,vl)
score,seed_g,seed_l,ZG,ZL,U,labels,maxres,comm_Z,vg_vals,vl_vals=best

# Define exact Pauli reps from the factorization unitary U
sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]],complex); sz=np.array([[1,0],[0,-1]],complex); I2=np.eye(2,dtype=complex)
XL=U@np.kron(sx,I2)@U.conj().T
YL=U@np.kron(sy,I2)@U.conj().T
ZL=U@np.kron(sz,I2)@U.conj().T
XG=U@np.kron(I2,sx)@U.conj().T
YG=U@np.kron(I2,sy)@U.conj().T
ZG=U@np.kron(I2,sz)@U.conj().T

# Lift to full Hilbert space as spectral representatives: C O C^dag
full_ops={
    'X_L': C@XL@C.conj().T,
    'Y_L': C@YL@C.conj().T,
    'Z_L': C@ZL@C.conj().T,
    'X_G': C@XG@C.conj().T,
    'Y_G': C@YG@C.conj().T,
    'Z_G': C@ZG@C.conj().T,
}

# Metrics
logical_metrics=pauli_metrics(XL,YL,ZL)
gauge_metrics=pauli_metrics(XG,YG,ZG)
comm_LG={}
for ln,Lop in [('X_L',XL),('Y_L',YL),('Z_L',ZL)]:
    for gn,Gop in [('X_G',XG),('Y_G',YG),('Z_G',ZG)]:
        comm_LG[f'[{ln},{gn}]']=float(np.linalg.norm(Lop@Gop-Gop@Lop,'fro'))

# algebra membership fits
alg_basis=prod_basis
com_basis=comm_basis
membership=[]
for name,O in [('X_L',XL),('Y_L',YL),('Z_L',ZL),('X_G',XG),('Y_G',YG),('Z_G',ZG)]:
    membership.append({
        'operator':name,
        'fit_to_interaction_algebra_residual':fit_residual_to_span(O,alg_basis),
        'fit_to_commutant_residual':fit_residual_to_span(O,com_basis),
    })

# subsystem residuals for several error sets in factor basis
def subsystem_residuals(errs):
    rows=[]; maxres=0.; rms=0.; n=0
    for na,Ea in errs:
        for nb,Eb in errs:
            M=C.conj().T@Ea.conj().T@Eb@C
            Mf=U.conj().T@M@U
            B=partial_trace_logical(Mf)
            res=residual_I_logical_tensor(Mf)
            maxres=max(maxres,res); rms+=res*res; n+=1
            rows.append({'Ea':na,'Eb':nb,'residual_I_L_tensor_B':res,'B00_real':float(B[0,0].real),'B00_imag':float(B[0,0].imag),'B01_real':float(B[0,1].real),'B01_imag':float(B[0,1].imag),'B10_real':float(B[1,0].real),'B10_imag':float(B[1,0].imag),'B11_real':float(B[1,1].real),'B11_imag':float(B[1,1].imag)})
    return rows, maxres, math.sqrt(rms/max(n,1))

right_rows,right_max,right_rms=subsystem_residuals(right_errors)
left_rows,left_max,left_rms=subsystem_residuals(left_errors)
local_rows,local_max,local_rms=subsystem_residuals(local_errors)

# Check full code against local plus right products? It should allow local as scalar and right as gauge; combined products may be I_L tensor B too.
combined_errors=local_errors + [(n,E) for n,E in right_errors if n!='I']
combined_rows,combined_max,combined_rms=subsystem_residuals(combined_errors)

# Matrix output in factor basis for compressed generators
factor_gen_rows=[]
for name,E in right_errors:
    M=C.conj().T@E@C
    Mf=U.conj().T@M@U
    factor_gen_rows.append({'operator':name,'matrix_factor_basis':json.dumps([[{'real':float(z.real),'imag':float(z.imag)} for z in row] for row in Mf])})

# Write outputs
summary={
    'code_candidate':{'irrep':'j=1','cluster_index':cluster_index,'energy':energy,'code_dim':code_dim,'basis_cluster_indices':[int(lo),int(hi)]},
    'factorization':{'seeds':{'gauge_seed':seed_g,'logical_seed':seed_l},'joint_projector_labels':labels,'right_subsystem_max_residual':right_max,'right_subsystem_rms_residual':right_rms,'left_subsystem_max_residual':left_max,'local_subsystem_max_residual':local_max,'combined_local_plus_right_max_residual':combined_max},
    'logical_pauli_metrics':logical_metrics,
    'gauge_pauli_metrics':gauge_metrics,
    'logical_gauge_commutators':comm_LG,
    'membership':membership,
    'interpretation':'The 4D spectral cluster admits an explicit C4 ~= L2 tensor G2 factorization. In this factorization right-Dic6 compressed error products act as I_L tensor B_G to numerical precision, so right-Dic6 shifts are gauge/syndrome actions while logical Pauli operators live in the commutant.',
}
(OUT/'subsystem_factorization_summary.json').write_text(json.dumps(summary,indent=2))

# CSVs
with open(OUT/'operator_membership.csv','w',newline='') as fcsv:
    w=csv.DictWriter(fcsv,fieldnames=list(membership[0].keys())); w.writeheader(); w.writerows(membership)
with open(OUT/'logical_gauge_commutators.csv','w',newline='') as fcsv:
    w=csv.DictWriter(fcsv,fieldnames=['commutator','fro_norm']); w.writeheader();
    for k,vv in comm_LG.items(): w.writerow({'commutator':k,'fro_norm':vv})
with open(OUT/'right_dic6_subsystem_products.csv','w',newline='') as fcsv:
    w=csv.DictWriter(fcsv,fieldnames=list(right_rows[0].keys())); w.writeheader(); w.writerows(right_rows)
with open(OUT/'left_dic6_subsystem_products.csv','w',newline='') as fcsv:
    w=csv.DictWriter(fcsv,fieldnames=list(left_rows[0].keys())); w.writeheader(); w.writerows(left_rows)
with open(OUT/'local_structural_subsystem_products.csv','w',newline='') as fcsv:
    w=csv.DictWriter(fcsv,fieldnames=list(local_rows[0].keys())); w.writeheader(); w.writerows(local_rows)
with open(OUT/'combined_local_right_subsystem_products.csv','w',newline='') as fcsv:
    w=csv.DictWriter(fcsv,fieldnames=list(combined_rows[0].keys())); w.writeheader(); w.writerows(combined_rows)
with open(OUT/'right_generator_matrices_factor_basis.csv','w',newline='') as fcsv:
    w=csv.DictWriter(fcsv,fieldnames=list(factor_gen_rows[0].keys())); w.writeheader(); w.writerows(factor_gen_rows)
# Pauli matrices in code basis as JSON (4x4)
def mat_to_json(M):
    return [[{'real':float(z.real),'imag':float(z.imag)} for z in row] for row in M]
matrices={name:mat_to_json(O) for name,O in [('X_L',XL),('Y_L',YL),('Z_L',ZL),('X_G',XG),('Y_G',YG),('Z_G',ZG)]}
matrices['factorization_unitary_code_to_LG']=mat_to_json(U)
(OUT/'logical_gauge_operators_code_basis.json').write_text(json.dumps(matrices,indent=2))

# Report markdown
report=f"""# UCD-504 Explicit Subsystem Factorization Workbench

## Purpose

Construct an explicit factorization of the 4D UCD-504 code cluster

```math
\\mathcal C_4 \\cong \\mathcal L_2 \\otimes \\mathcal G_2
```

and produce explicit logical/gauge Pauli operators.

## Code cluster

- Irrep: `j=1`
- Cluster index: `{cluster_index}`
- Energy: `{energy:.15f}`
- Code dimension: `{code_dim}`

## Constructed factorization

The workbench compressed the right-Dic6 error-product algebra `C^dag E_a^dag E_b C`, computed its commutant, and built commuting Pauli triples from the algebra and commutant. The resulting joint eigenbasis gives the factorization unitary `U`, with basis ordering:

```text
|L=+,G=+>, |L=+,G=->, |L=-,G=+>, |L=-,G=->
```

In that basis, the exact representatives are:

```math
\\bar X_L = X \\otimes I, \\quad \\bar Y_L=Y\\otimes I, \\quad \\bar Z_L=Z\\otimes I,
```

```math
X_G = I \\otimes X, \\quad Y_G=I\\otimes Y, \\quad Z_G=I\\otimes Z.
```

The physical spectral representatives are `C O C^dag` in the full 504D Hilbert space.

## Subsystem condition

For right-Dic6 errors, the compressed products satisfy

```math
C^\\dag E_a^\\dag E_b C = I_L \\otimes B_{{ab}}
```

up to numerical residual:

- max residual: `{right_max:.3e}`
- RMS residual: `{right_rms:.3e}`

For the combined local-structural plus right-Dic6 errors:

- max residual: `{combined_max:.3e}`
- RMS residual: `{combined_rms:.3e}`

This verifies the intended interpretation: right-Dic6 shifts act on the gauge factor, while the logical qubit is protected.

## Pauli checks

Logical Pauli max residuals:

- X^2=I: `{logical_metrics['X2_I']:.3e}`
- Y^2=I: `{logical_metrics['Y2_I']:.3e}`
- Z^2=I: `{logical_metrics['Z2_I']:.3e}`
- XY=iZ: `{logical_metrics['XY_iZ']:.3e}`

Gauge Pauli max residuals:

- X^2=I: `{gauge_metrics['X2_I']:.3e}`
- Y^2=I: `{gauge_metrics['Y2_I']:.3e}`
- Z^2=I: `{gauge_metrics['Z2_I']:.3e}`
- XY=iZ: `{gauge_metrics['XY_iZ']:.3e}`

Maximum logical-gauge commutator residual:

`{max(comm_LG.values()):.3e}`

## Interpretation

This turns the earlier algebraic subsystem signature into an explicit logical-qubit model:

```math
\\mathcal C_4 = \\mathcal L_2 \\otimes \\mathcal G_2.
```

The right-Dic6 fiber is gauge/syndrome, and the protected logical information is carried by the commutant factor.

## Remaining work

1. Identify physical control/readout operators that approximate the spectral logical Pauli operators.
2. Build an explicit recovery circuit or measurement protocol for the gauge syndrome.
3. Test robustness under non-ideal right-Dic6 errors and dissipative noise.
"""
(OUT/'Subsystem_Factorization_Report.md').write_text(report)

# Build zip
zip_path=Path('/mnt/data/UCD_504_Subsystem_Factorization_Workbench.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(Path(__file__), 'ucd_504_subsystem_factorization_build.py')
    for p in OUT.iterdir():
        z.write(p, p.relative_to(OUT.parent))
print(json.dumps(summary, indent=2)[:6000])
print(zip_path)
