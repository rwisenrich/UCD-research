# UCD-504 Explicit Subsystem Factorization Workbench

## Purpose

Construct an explicit factorization of the 4D UCD-504 code cluster

```math
\mathcal C_4 \cong \mathcal L_2 \otimes \mathcal G_2
```

and produce explicit logical/gauge Pauli operators.

## Code cluster

- Irrep: `j=1`
- Cluster index: `14`
- Energy: `5.145571667152207`
- Code dimension: `4`

## Constructed factorization

The workbench compressed the right-Dic6 error-product algebra `C^dag E_a^dag E_b C`, computed its commutant, and built commuting Pauli triples from the algebra and commutant. The resulting joint eigenbasis gives the factorization unitary `U`, with basis ordering:

```text
|L=+,G=+>, |L=+,G=->, |L=-,G=+>, |L=-,G=->
```

In that basis, the exact representatives are:

```math
\bar X_L = X \otimes I, \quad \bar Y_L=Y\otimes I, \quad \bar Z_L=Z\otimes I,
```

```math
X_G = I \otimes X, \quad Y_G=I\otimes Y, \quad Z_G=I\otimes Z.
```

The physical spectral representatives are `C O C^dag` in the full 504D Hilbert space.

## Subsystem condition

For right-Dic6 errors, the compressed products satisfy

```math
C^\dag E_a^\dag E_b C = I_L \otimes B_{ab}
```

up to numerical residual:

- max residual: `2.573e-15`
- RMS residual: `2.124e-15`

For the combined local-structural plus right-Dic6 errors:

- max residual: `1.550e-14`
- RMS residual: `3.429e-15`

This verifies the intended interpretation: right-Dic6 shifts act on the gauge factor, while the logical qubit is protected.

## Pauli checks

Logical Pauli max residuals:

- X^2=I: `5.586e-16`
- Y^2=I: `6.569e-16`
- Z^2=I: `6.187e-16`
- XY=iZ: `5.615e-16`

Gauge Pauli max residuals:

- X^2=I: `7.193e-16`
- Y^2=I: `6.760e-16`
- Z^2=I: `6.617e-16`
- XY=iZ: `4.887e-16`

Maximum logical-gauge commutator residual:

`7.784e-16`

## Interpretation

This turns the earlier algebraic subsystem signature into an explicit logical-qubit model:

```math
\mathcal C_4 = \mathcal L_2 \otimes \mathcal G_2.
```

The right-Dic6 fiber is gauge/syndrome, and the protected logical information is carried by the commutant factor.

## Remaining work

1. Identify physical control/readout operators that approximate the spectral logical Pauli operators.
2. Build an explicit recovery circuit or measurement protocol for the gauge syndrome.
3. Test robustness under non-ideal right-Dic6 errors and dissipative noise.
