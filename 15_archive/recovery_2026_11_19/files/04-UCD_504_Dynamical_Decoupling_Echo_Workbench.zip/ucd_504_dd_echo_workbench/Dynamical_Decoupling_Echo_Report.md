# UCD-504 Dynamical-Decoupling / Echo Workbench

This workbench runs full 84-dimensional `j=1` block simulations for the UCD-504 subsystem code after adding dynamical-decoupling/echo sequences.

## Model

The code cluster is `j=1`, cluster 14, with energy 5.145571667152.  The cluster factors as a 4D subsystem `L2 x G2`.  Controls `O_X,O_Y,O_Z` are fitted left-Dic6 controls that compress to logical Pauli operators with residuals:

- X: 6.750e-16
- Y: 4.969e-16
- Z: 6.299e-16

## Sequences tested

- `idle_baseline`: no echo memory interval.
- `idle_hahn`: Hahn-style X echo during memory interval.
- `idle_xy4`: XY4-style four-pulse memory interval.
- `rx_baseline`: direct RX(pi/2).
- `rx_echo_x`: split RX(pi/2) with X echo pulses.
- `rx_symmetric_echo`: longer symmetric X-axis composite stress-test sequence.

## Interpretation

The echo sequences are most meaningful for idle/memory protection against logical-Z dephasing.  During driven gates, extra echo pulses increase the duration, so they only help if the dephasing suppression outweighs the added exposure and amplitude-control error.

See CSV outputs for aggregate results and best sequence selections.
