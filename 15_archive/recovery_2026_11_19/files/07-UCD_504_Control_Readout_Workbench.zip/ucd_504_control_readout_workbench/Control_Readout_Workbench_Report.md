# UCD-504 Physical Control/Readout Operator Workbench

## Purpose

Use the explicit subsystem factorization

```math
\mathcal C_4 \cong \mathcal L_2 \otimes \mathcal G_2
```

to search for simple UCD operators whose compression to the code cluster acts like logical control/readout operators

```math
ar X_L = X\otimes I_G,\qquad ar Z_L = Z\otimes I_G.
```

## Code space

- Irrep: `j=1`
- Cluster index: `14`
- Energy: `5.145571667152207`
- Dimension: `4 = 2 logical x 2 gauge`

The right-Dic6 interaction algebra remains gauge with residual `2.573e-15`.

## Search logic

For each accessible UCD operator `O`, the workbench computes

```math
O_C = U^\dagger C^\dagger O C U
```

in the factor basis. It then decomposes `O_C` into the Pauli tensor basis

```math
{I,X,Y,Z}_L \otimes {I,X,Y,Z}_G.
```

A useful physical logical control/readout has most of its traceless weight in `XI`, `YI`, or `ZI`, with little gauge leakage.

## Best single-operator results

Best single approximate `X_L`:

- operator: `Left_refY_a1x`
- category: `Left_Dic6_reflection`
- residual to `XI`: `0.602373`
- logical-only residual: `1.05296e-15`
- target purity: `0.798215`

Best single approximate `Z_L`:

- operator: `Left_refY_a3x`
- category: `Left_Dic6_reflection`
- residual to `ZI`: `0.245284`
- logical-only residual: `9.36319e-16`
- target purity: `0.969451`

## Best linear-combination results

Best `X_L` fit:

- operator set: `all_with_products`
- residual: `9.71647e-16`
- number of candidates: `172`

Best `Z_L` fit:

- operator set: `all_simple_no_products`
- residual: `7.98367e-16`
- number of candidates: `94`

The detailed coefficients are in `control_linear_span_fits.csv` and `control_fit_details.json`.

## Interpretation

The key physical split is now clear:

- right-Dic6 actions are gauge/syndrome actions;
- logical operators must come from the commutant, and the simplest accessible commutant candidates are left-Dic6 controls;
- if a left-Dic6 or structural-left combination fits `XI` or `ZI` with small residual, it is a candidate physical gate/readout operator.

## Next step

Use the best fitted logical controls to simulate driven dynamics

```math
H(t)=H_{504}+u_X(t)O_X+u_Z(t)O_Z
```

and verify that the resulting evolution rotates the logical qubit while leaving the gauge subsystem irrelevant.
