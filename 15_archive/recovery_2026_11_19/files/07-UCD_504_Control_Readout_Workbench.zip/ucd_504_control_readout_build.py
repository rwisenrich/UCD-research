#!/usr/bin/env python3
from pathlib import Path
import sys, json, csv, math, zipfile
import numpy as np

sys.path.insert(0, '/mnt/data/ucd_504_master_hamiltonian')
import ucd_504_master_hamiltonian as ucd

OUT = Path('/mnt/data/ucd_504_control_readout_workbench')
OUT.mkdir(exist_ok=True)

# ---------- helpers ----------
def lift(A,B,C):
    return np.kron(np.kron(A,B),C)

def E(n,i,j):
    M=np.zeros((n,n),complex); M[i,j]=1; return M

def cluster_ranges(vals,tol=1e-8):
    out=[]; i=0; n=len(vals)
    while i<n:
        j=i+1
        while j<n and abs(vals[j]-vals[i])<tol:
            j+=1
        out.append((i,j,float(np.mean(vals[i:j]))))
        i=j
    return out

def span_basis(mats, tol=1e-10):
    vec_basis=[]; mat_basis=[]
    for M in mats:
        v=M.reshape(-1).astype(complex).copy()
        for q in vec_basis:
            v -= q*np.vdot(q,v)
        n=np.linalg.norm(v)
        if n>tol:
            q=v/n
            vec_basis.append(q)
            mat_basis.append(q.reshape(M.shape))
    return mat_basis

def commutant_basis(mats,n,tol=1e-9):
    I=np.eye(n,dtype=complex); rows=[]
    for M in mats:
        rows.append(np.kron(M.T,I)-np.kron(I,M))
    L=np.vstack(rows)
    U,S,Vh=np.linalg.svd(L)
    thr=max(tol, tol*S[0] if len(S) else tol)
    rank=int(np.sum(S>thr))
    null=Vh.conj().T[:,rank:]
    return span_basis([null[:,i].reshape(n,n) for i in range(null.shape[1])],tol=1e-8)

def hermitian_basis_from_span(basis,tol=1e-8):
    outs=[]
    for B in basis:
        outs += [(B+B.conj().T)/2, (B-B.conj().T)/(2j)]
    return span_basis(outs,tol=tol)

def traceless_hermitian_basis(basis,n,tol=1e-8):
    I=np.eye(n,dtype=complex); outs=[]
    for H in hermitian_basis_from_span(basis,tol):
        H=(H+H.conj().T)/2
        H=H-(np.trace(H)/n)*I
        if np.linalg.norm(H,'fro')>tol:
            outs.append(H)
    return span_basis(outs,tol=tol)

def random_hermitian_from_basis(basis,seed=0):
    rng=np.random.default_rng(seed)
    H=sum(c*B for c,B in zip(rng.normal(size=len(basis)),basis))
    H=(H+H.conj().T)/2
    H=H-(np.trace(H)/H.shape[0])*np.eye(H.shape[0])
    return H

def sign_operator_from_hermitian(H):
    H=(H+H.conj().T)/2
    vals,vecs=np.linalg.eigh(H)
    order=np.argsort(vals)
    signs=np.zeros(len(vals)); signs[order[:len(vals)//2]]=-1.; signs[order[len(vals)//2:]]=1.
    Z=vecs@np.diag(signs)@vecs.conj().T
    return (Z+Z.conj().T)/2

def joint_factor_unitary(ZL,ZG):
    I=np.eye(4,dtype=complex); cols=[]
    for l in [1,-1]:
        for g in [1,-1]:
            P=(I+l*ZL)@(I+g*ZG)/4
            vals,vecs=np.linalg.eigh((P+P.conj().T)/2)
            v=vecs[:,np.argmax(vals.real)]
            k=np.argmax(np.abs(v))
            if abs(v[k])>1e-12:
                v=v*np.exp(-1j*np.angle(v[k]))
            cols.append(v)
    U=np.column_stack(cols)
    U,_=np.linalg.qr(U)
    return U

def partial_trace_logical(M4):
    # Returns gauge operator B such that best I_L tensor B approximates M4.
    B=np.zeros((2,2),complex)
    for g in range(2):
        for gp in range(2):
            B[g,gp]=0.5*(M4[0*2+g,0*2+gp]+M4[1*2+g,1*2+gp])
    return B

def residual_to_Ilogical(M4):
    B=partial_trace_logical(M4)
    return float(np.linalg.norm(M4-np.kron(np.eye(2),B),'fro'))

def mat_to_json(M):
    return [[{'real':float(z.real),'imag':float(z.imag)} for z in row] for row in M]

def compress_factor(O,C,U):
    return U.conj().T@(C.conj().T@O@C)@U

def pauli_coeffs(M):
    sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]],complex); sz=np.array([[1,0],[0,-1]],complex); I2=np.eye(2,dtype=complex)
    labels=['I','X','Y','Z']; mats=[I2,sx,sy,sz]
    coeff={}
    for a,A in zip(labels,mats):
        for b,B in zip(labels,mats):
            P=np.kron(A,B)
            coeff[a+b]=np.trace(P.conj().T@M)/4.0
    return coeff

def score_for_target(M,target_label):
    coeff=pauli_coeffs(M)
    scalar=coeff['II']*np.eye(4)
    traceless=M-scalar
    norm=float(np.linalg.norm(traceless,'fro'))
    if norm<1e-12:
        return {'amp_abs':0.0,'amp_real':0.0,'amp_imag':0.0,'purity':0.0,'residual':1.0,'logical_only_residual':1.0,'norm':norm}
    target_amp=coeff[target_label]
    Ptarget=PAULI4[target_label]
    fit=scalar+target_amp*Ptarget
    residual=float(np.linalg.norm(M-fit,'fro')/max(norm,1e-15))
    logical_fit=scalar+sum(coeff[l+'I']*PAULI4[l+'I'] for l in ['X','Y','Z'])
    logical_only_residual=float(np.linalg.norm(M-logical_fit,'fro')/max(norm,1e-15))
    purity=float(abs(target_amp)*2/max(norm,1e-15)) # target component fro norm = 2|amp|
    return {'amp_abs':float(abs(target_amp)),'amp_real':float(target_amp.real),'amp_imag':float(target_amp.imag),'purity':purity,'residual':residual,'logical_only_residual':logical_only_residual,'norm':norm}

def vectorize_hermitian(M):
    v=M.reshape(-1)
    return np.concatenate([v.real,v.imag])

def fit_linear_span(candidates,target_label):
    # candidates: list of (name,Mfac Hermitian-ish)
    target=PAULI4[target_label]
    # Remove scalar components from candidates and target, use real coefficients.
    mats=[]; names=[]
    for name,M in candidates:
        H=(M+M.conj().T)/2
        H=H-(np.trace(H)/4)*np.eye(4)
        n=np.linalg.norm(H,'fro')
        if n>1e-10:
            mats.append(H); names.append(name)
    A=np.column_stack([vectorize_hermitian(M) for M in mats]) if mats else np.zeros((32,0))
    y=vectorize_hermitian(target)
    coef,_,_,_=np.linalg.lstsq(A,y,rcond=None) if A.shape[1] else (np.array([]),None,None,None)
    rec=sum(c*M for c,M in zip(coef,mats)) if mats else np.zeros((4,4),complex)
    res=float(np.linalg.norm(target-rec,'fro')/np.linalg.norm(target,'fro'))
    # Top coefficients by absolute value.
    top=sorted([(names[i],float(coef[i])) for i in range(len(names))], key=lambda x: abs(x[1]), reverse=True)[:20]
    return res, top, rec

# Pauli basis in factor basis.
sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]],complex); sz=np.array([[1,0],[0,-1]],complex); I2=np.eye(2,dtype=complex)
PAULI4={}
for a,A in [('I',I2),('X',sx),('Y',sy),('Z',sz)]:
    for b,B in [('I',I2),('X',sx),('Y',sy),('Z',sz)]:
        PAULI4[a+b]=np.kron(A,B)

# ---------- Build code and factorization ----------
H=ucd.build_H504()
v=ucd.V7_ops(); f=ucd.F3_ops(); I7=v['I7']; I3=f['I3']; I24=np.eye(24,dtype=complex); I504=np.eye(504,dtype=complex)
La=ucd.left_regular((1,0)); Lx=ucd.left_regular((0,1)); La6=ucd.left_regular((6,0))
Ra=ucd.right_regular((1,0)); Rx=ucd.right_regular((0,1)); Ra6=ucd.right_regular((6,0))

ir=[x for x in ucd.irreps() if x.name=='j=1'][0]
Hb,B=ucd.irrep_block(H,ucd.isotypic_projector(ir))
vals,vecs=np.linalg.eigh(Hb)
clusters=cluster_ranges(vals)
cluster_index=14
lo,hi,energy=clusters[cluster_index]
C=B@vecs[:,lo:hi]
C,_=np.linalg.qr(C)

# Right error product algebra for subsystem split.
right_errors=[('I',I504),('R_a',lift(I7,I3,Ra)),('R_x',lift(I7,I3,Rx)),('R_a6',lift(I7,I3,Ra6))]
prod_mats=[]
for _,Ea in right_errors:
    for _,Eb in right_errors:
        prod_mats.append(C.conj().T@Ea.conj().T@Eb@C)
prod_basis=span_basis(prod_mats,tol=1e-8)
comm_basis=commutant_basis(prod_basis,4,tol=1e-8)
alg_tr=traceless_hermitian_basis(prod_basis,4,tol=1e-8)
com_tr=traceless_hermitian_basis(comm_basis,4,tol=1e-8)
# reproduce deterministic factorization search from previous build
best=None
for seed_g in range(20):
    ZG=sign_operator_from_hermitian(random_hermitian_from_basis(alg_tr,seed=100+seed_g))
    for seed_l in range(20):
        ZL=sign_operator_from_hermitian(random_hermitian_from_basis(com_tr,seed=200+seed_l))
        comm=float(np.linalg.norm(ZL@ZG-ZG@ZL,'fro'))
        U=joint_factor_unitary(ZL,ZG)
        maxres=max(residual_to_Ilogical(U.conj().T@M@U) for M in prod_mats)
        score=comm+maxres
        if best is None or score<best[0]:
            best=(score,seed_g,seed_l,U,maxres,comm)
_,seed_g,seed_l,U,right_maxres,comm_Z=best

# ---------- Candidate operator library ----------
terms=ucd.build_terms()
coeff_names=terms.names
operators=[]
def add(name,O,category):
    Hh=(O+O.conj().T)/2
    operators.append({'name':name,'category':category,'O':Hh})

# Hamiltonian terms
for name,T in zip(terms.names,terms.terms):
    add(name,T,'H504_terms')
# V7 accessible
for name in ['Pc','R7','A7','Rring','Tp','Tm']:
    if name in v:
        add('V7_'+name,lift(v[name],I3,I24),'V7_structural')
for i in range(7):
    add(f'V7_P{i}',lift(E(7,i,i),I3,I24),'V7_projector')
# Family accessible, including Hermitian matrix units
for name in ['XZ','JZ','H','H2','P0_minus_P2']:
    add('F3_'+name,lift(I7,f[name],I24),'F3_structural')
for i in range(3):
    add(f'F3_P{i}',lift(I7,E(3,i,i),I24),'F3_projector')
for i in range(3):
    for j in range(i+1,3):
        X=E(3,i,j)+E(3,j,i); Y=1j*(E(3,i,j)-E(3,j,i))
        add(f'F3_X{i}{j}',lift(I7,X,I24),'F3_matrix_unit')
        add(f'F3_Y{i}{j}',lift(I7,Y,I24),'F3_matrix_unit')
# Left and right Dic6 group operators
for n in range(1,7):
    L=ucd.left_regular((n,0)); Rr=ucd.right_regular((n,0))
    add(f'Left_cos_a{n}',lift(I7,I3,0.5*(L+L.conj().T)),'Left_Dic6')
    add(f'Left_sin_a{n}',lift(I7,I3,(L-L.conj().T)/(2j)),'Left_Dic6')
    add(f'Right_cos_a{n}',lift(I7,I3,0.5*(Rr+Rr.conj().T)),'Right_Dic6_gauge')
    add(f'Right_sin_a{n}',lift(I7,I3,(Rr-Rr.conj().T)/(2j)),'Right_Dic6_gauge')
# reflections x with a^n x
for n in range(12):
    g=(n,1)
    L=ucd.left_regular(g); Rr=ucd.right_regular(g)
    add(f'Left_ref_a{n}x',lift(I7,I3,0.5*(L+L.conj().T)),'Left_Dic6_reflection')
    add(f'Left_refY_a{n}x',lift(I7,I3,(L-L.conj().T)/(2j)),'Left_Dic6_reflection')
    add(f'Right_ref_a{n}x',lift(I7,I3,0.5*(Rr+Rr.conj().T)),'Right_Dic6_gauge')
# Products: physically plausible controls coupling left Dic6 to structural terms (limited set)
base_struct=[('V7_A7',lift(v['A7'],I3,I24)),('V7_Rring',lift(v['Rring'],I3,I24)),('F3_XZ',lift(I7,f['XZ'],I24)),('F3_JZ',lift(I7,f['JZ'],I24)),('F3_H',lift(I7,f['H'],I24)),('F3_P0mP2',lift(I7,f['P0_minus_P2'],I24))]
left_basic=[]
for n in [1,2,3,6]:
    L=ucd.left_regular((n,0)); left_basic.append((f'Left_cos_a{n}',lift(I7,I3,0.5*(L+L.conj().T))))
    left_basic.append((f'Left_sin_a{n}',lift(I7,I3,(L-L.conj().T)/(2j))))
for n in [0,1,2,3,6]:
    L=ucd.left_regular((n,1)); left_basic.append((f'Left_ref_a{n}x',lift(I7,I3,0.5*(L+L.conj().T))))
for sn,S in base_struct:
    for ln,Lop in left_basic:
        add(f'{sn}__{ln}', S@Lop, 'struct_x_LeftDic6')

# compress all candidates and score
single_rows=[]; compressed=[]
for op in operators:
    M=compress_factor(op['O'],C,U)
    M=(M+M.conj().T)/2
    compressed.append((op['name'],op['category'],M))
    for target in ['XI','ZI','YI']:
        sc=score_for_target(M,target)
        single_rows.append({'operator':op['name'],'category':op['category'],'target':target,**sc})

# linear fits by category groups
sets={
    'H504_terms': ['H504_terms'],
    'V7_F3_structural': ['V7_structural','V7_projector','F3_structural','F3_projector','F3_matrix_unit'],
    'left_dic6_basic': ['Left_Dic6','Left_Dic6_reflection'],
    'right_dic6_gauge': ['Right_Dic6_gauge'],
    'struct_x_left_dic6': ['struct_x_LeftDic6'],
    'all_simple_no_products': ['H504_terms','V7_structural','V7_projector','F3_structural','F3_projector','F3_matrix_unit','Left_Dic6','Left_Dic6_reflection','Right_Dic6_gauge'],
    'all_with_products': ['H504_terms','V7_structural','V7_projector','F3_structural','F3_projector','F3_matrix_unit','Left_Dic6','Left_Dic6_reflection','Right_Dic6_gauge','struct_x_LeftDic6']
}
fit_rows=[]; fit_details={}
for setname,cats in sets.items():
    cand=[(n,M) for n,cat,M in compressed if cat in cats]
    for target in ['XI','ZI','YI']:
        res,top,rec=fit_linear_span(cand,target)
        fit_rows.append({'operator_set':setname,'target':target,'relative_residual':res,'num_candidates':len(cand),'top_coefficients_json':json.dumps(top)})
        fit_details[f'{setname}_{target}']={'residual':res,'top_coefficients':top,'reconstruction_matrix':mat_to_json(rec)}

# identify best single ops for X and Z
best_single={}
for target in ['XI','ZI','YI']:
    rows=[r for r in single_rows if r['target']==target]
    rows_sorted=sorted(rows,key=lambda r:(r['residual'], -r['purity']))
    best_single[target]=rows_sorted[:10]

# exact interpretations: left group actions in factor basis (selected)
selected_names=['Left_cos_a1','Left_sin_a1','Left_cos_a2','Left_sin_a2','Left_cos_a3','Left_sin_a3','Left_cos_a6','Left_ref_a0x','Left_ref_a1x','Left_ref_a2x','Left_ref_a3x','Right_cos_a1','Right_ref_a0x']
selected_mats={}
for name,cat,M in compressed:
    if name in selected_names:
        selected_mats[name]=mat_to_json(M)

summary={
    'code_candidate': {'irrep':'j=1','cluster_index':cluster_index,'energy':energy,'dim':4},
    'factorization': {'gauge_seed':seed_g,'logical_seed':seed_l,'right_subsystem_max_residual':right_maxres,'commuting_Z_seed_residual':comm_Z},
    'best_single': best_single,
    'linear_fit_summary': fit_rows,
    'interpretation': {
        'control_readout_status': 'Left-Dic6 operators are the natural physical control/readout candidates because right-Dic6 is the gauge algebra and the logical algebra is its commutant.',
        'success_condition': 'A useful control/readout operator should compress to X_L tensor I_G or Z_L tensor I_G with small residual in the L2 x G2 factor basis.'
    }
}

# write outputs
with open(OUT/'control_single_operator_scores.csv','w',newline='') as fcsv:
    field=list(single_rows[0].keys()); w=csv.DictWriter(fcsv,fieldnames=field); w.writeheader(); w.writerows(single_rows)
with open(OUT/'control_linear_span_fits.csv','w',newline='') as fcsv:
    field=list(fit_rows[0].keys()); w=csv.DictWriter(fcsv,fieldnames=field); w.writeheader(); w.writerows(fit_rows)
(OUT/'control_fit_details.json').write_text(json.dumps(fit_details,indent=2))
(OUT/'selected_operator_matrices_factor_basis.json').write_text(json.dumps(selected_mats,indent=2))
(OUT/'control_readout_summary.json').write_text(json.dumps(summary,indent=2))

# report
# make concise tables
best_x=best_single['XI'][0]; best_z=best_single['ZI'][0]
fit_best_x=sorted([r for r in fit_rows if r['target']=='XI'], key=lambda r:r['relative_residual'])[0]
fit_best_z=sorted([r for r in fit_rows if r['target']=='ZI'], key=lambda r:r['relative_residual'])[0]
report=f'''# UCD-504 Physical Control/Readout Operator Workbench

## Purpose

Use the explicit subsystem factorization

```math
\mathcal C_4 \cong \mathcal L_2 \otimes \mathcal G_2
```

to search for simple UCD operators whose compression to the code cluster acts like logical control/readout operators

```math
\bar X_L = X\otimes I_G,\qquad \bar Z_L = Z\otimes I_G.
```

## Code space

- Irrep: `j=1`
- Cluster index: `{cluster_index}`
- Energy: `{energy:.15f}`
- Dimension: `4 = 2 logical x 2 gauge`

The right-Dic6 interaction algebra remains gauge with residual `{right_maxres:.3e}`.

## Search logic

For each accessible UCD operator `O`, the workbench computes

```math
O_C = U^\dagger C^\dagger O C U
```

in the factor basis. It then decomposes `O_C` into the Pauli tensor basis

```math
{{I,X,Y,Z}}_L \otimes {{I,X,Y,Z}}_G.
```

A useful physical logical control/readout has most of its traceless weight in `XI`, `YI`, or `ZI`, with little gauge leakage.

## Best single-operator results

Best single approximate `X_L`:

- operator: `{best_x['operator']}`
- category: `{best_x['category']}`
- residual to `XI`: `{best_x['residual']:.6g}`
- logical-only residual: `{best_x['logical_only_residual']:.6g}`
- target purity: `{best_x['purity']:.6g}`

Best single approximate `Z_L`:

- operator: `{best_z['operator']}`
- category: `{best_z['category']}`
- residual to `ZI`: `{best_z['residual']:.6g}`
- logical-only residual: `{best_z['logical_only_residual']:.6g}`
- target purity: `{best_z['purity']:.6g}`

## Best linear-combination results

Best `X_L` fit:

- operator set: `{fit_best_x['operator_set']}`
- residual: `{fit_best_x['relative_residual']:.6g}`
- number of candidates: `{fit_best_x['num_candidates']}`

Best `Z_L` fit:

- operator set: `{fit_best_z['operator_set']}`
- residual: `{fit_best_z['relative_residual']:.6g}`
- number of candidates: `{fit_best_z['num_candidates']}`

The detailed coefficients are in `control_linear_span_fits.csv` and `control_fit_details.json`.

## Interpretation

The key physical split is now clear:

- right-Dic6 actions are gauge/syndrome actions;
- logical operators must come from the commutant, and the simplest accessible commutant candidates are left-Dic6 controls;
- if a left-Dic6 or structural-left combination fits `XI` or `ZI` with small residual, it is a candidate physical gate/readout operator.

## Next step

Use the best fitted logical controls to simulate driven dynamics

```math
H(t)=H_{{504}}+u_X(t)O_X+u_Z(t)O_Z
```

and verify that the resulting evolution rotates the logical qubit while leaving the gauge subsystem irrelevant.
'''
(OUT/'Control_Readout_Workbench_Report.md').write_text(report)

zip_path=Path('/mnt/data/UCD_504_Control_Readout_Workbench.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(Path(__file__),'ucd_504_control_readout_build.py')
    for p in OUT.iterdir():
        z.write(p,p.relative_to(OUT.parent))
print(json.dumps({'zip':str(zip_path),'best_x':best_x,'best_z':best_z,'fit_best_x':fit_best_x,'fit_best_z':fit_best_z},indent=2)[:10000])
