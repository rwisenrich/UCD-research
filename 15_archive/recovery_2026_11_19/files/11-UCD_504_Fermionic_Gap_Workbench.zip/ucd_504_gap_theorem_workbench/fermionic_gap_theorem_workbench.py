import numpy as np, math, json, csv
from pathlib import Path
TAU=1/72; EXP=math.exp(-TAU)
ELEMS=[(k,e) for e in (0,1) for k in range(12)]; IDX={g:i for i,g in enumerate(ELEMS)}
def mul(g,h):
    k,e=g; l,f=h
    return ((k + ((-1)**e)*l + (6 if e==1 and f==1 else 0))%12, e^f)
def inv(g):
    for h in ELEMS:
        if mul(g,h)==(0,0) and mul(h,g)==(0,0): return h
    raise ValueError(g)
def left(g):
    M=np.zeros((24,24),complex)
    for j,h in enumerate(ELEMS): M[IDX[mul(g,h)],j]=1
    return M
def right(g):
    M=np.zeros((24,24),complex); gi=inv(g)
    for j,h in enumerate(ELEMS): M[IDX[mul(h,gi)],j]=1
    return M
def chi_2d(j): return lambda g: (2*math.cos(math.pi*j*g[0]/6) if g[1]==0 else 0.0)
def projector(chi,dim):
    P=np.zeros((24,24),complex)
    for g in ELEMS: P+=np.conj(chi(g))*right(g)
    return (dim/24)*P
def basis_projector(P):
    w,U=np.linalg.eigh((P+P.conj().T)/2)
    return U[:,w>0.5]
def E(n,i,j):
    M=np.zeros((n,n),complex); M[i,j]=1; return M
def V7():
    I=np.eye(7,dtype=complex); Pc=E(7,0,0); R=I-Pc; A=np.zeros((7,7),complex)
    for i in range(1,7): A[0,i]=A[i,0]=1
    Tp=np.zeros((7,7),complex); Tm=np.zeros((7,7),complex)
    for i in range(1,7): Tp[1+(i%6),i]=1; Tm[1+((i-2)%6),i]=1
    return I,R,A,Tp+Tm
def F3():
    I=np.eye(3,dtype=complex); R=np.array([[0,1,0],[0,0,1],[1,0,0]],complex)
    X=R+R.conj().T; J=(R-R.conj().T)/(1j*math.sqrt(3)); P0mP2=E(3,0,0)-E(3,2,2)
    return I,X,J,P0mP2
def clusters(eigs,tol=1e-8):
    out=[]; cur=[float(eigs[0])]
    for x in eigs[1:]:
        x=float(x)
        if abs(x-cur[-1])<tol: cur.append(x)
        else: out.append((sum(cur)/len(cur),len(cur))); cur=[x]
    out.append((sum(cur)/len(cur),len(cur)))
    return out
I7,R7,A7,Rring=V7(); I3,XZ,JZ,P0mP2=F3(); I24=np.eye(24,dtype=complex)
La=left((1,0)); Lx=left((0,1)); La6=left((6,0)); ro=0.5*(La+La.conj().T); rc=0.5*(Lx+Lx.conj().T)
coeff=np.array([1.0,0.5,0.1,0.1,1.1,0.1,0.3])
base_terms=[('T1_star',A7,I3,I24),('T2_Z3_hopping',I7,XZ,I24),('T3_leaf_ring',Rring,I3,I24),('T4_central_parity_star',A7,I3,La6),('T5_orient_XZ',I7,XZ,ro),('T6_curr_JZ',I7,JZ,rc),('T7_leaf_generation_selector',R7,P0mP2,I24)]
def kron3(A,B,C): return np.kron(np.kron(A,B),C)
def cluster_projector(H,center,tol=1e-7):
    w,U=np.linalg.eigh(H)
    ids=np.where(abs(w-center)<tol)[0]
    return U[:,ids]@U[:,ids].conj().T, len(ids)
rows=[]; sens=[]; finite=[]; block_details={}
for j in range(1,6):
    P=projector(chi_2d(j),2); B=basis_projector(P) # 24x4
    terms=[]
    for name,A,F,C in base_terms:
        Cb=B.conj().T@C@B
        terms.append((name,kron3(A,F,Cb)))
    H=sum(c*T for c,(_,T) in zip(coeff,terms))*EXP
    eigs=np.linalg.eigvalsh(H).real; cl=clusters(eigs); gaps=[cl[i+1][0]-cl[i][0] for i in range(len(cl)-1)]
    target=0.2*EXP; gi=int(np.argmin(abs(np.array(gaps)-target)))
    low,high=cl[gi],cl[gi+1]; gap=gaps[gi]
    rows.append({'irrep':f'j={j}','block_dim':len(eigs),'num_distinct_clusters':len(cl),'gap_cluster_index':gi,'low_center':low[0],'low_mult':low[1],'high_center':high[0],'high_mult':high[1],'gap':gap,'target':target,'deviation':abs(gap-target)})
    Pl,dl=cluster_projector(H,low[0]); Pu,du=cluster_projector(H,high[0])
    for idx,(name,Tb) in enumerate(terms):
        deriv=EXP*((np.trace(Pu@Tb).real/du)-(np.trace(Pl@Tb).real/dl))
        sens.append({'irrep':f'j={j}','term':name,'hellmann_derivative':deriv})
        eps=1e-6
        cp=coeff.copy(); cp[idx]+=eps
        Hp=sum(c*T for c,(_,T) in zip(cp,terms))*EXP
        clp=clusters(np.linalg.eigvalsh(Hp).real,tol=1e-7)
        fd=(clp[gi+1][0]-clp[gi][0]-gap)/eps if gi+1<len(clp) else float('nan')
        finite.append({'irrep':f'j={j}','term':name,'finite_derivative_same_cluster_index':fd})
    block_details[f'j={j}']={'first_clusters':cl[:12],'target_gap_index':gi}
out=Path('/mnt/data/ucd_504_gap_theorem_workbench'); out.mkdir(exist_ok=True)
for fname,data in [('fermionic_gap_clusters.csv',rows),('fermionic_gap_hellmann_sensitivities.csv',sens),('fermionic_gap_finite_derivatives.csv',finite)]:
    with open(out/fname,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0].keys())); w.writeheader(); w.writerows(data)
summary={'tau':TAU,'exp_minus_tau':EXP,'target_one_fifth_exp':0.2*EXP,'max_gap_deviation':max(r['deviation'] for r in rows),'gap_rows':rows,'block_details':block_details}
with open(out/'fermionic_gap_summary.json','w') as f: json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2))
print('\nNonzero Hellmann centroid derivatives (>1e-8):')
for r in sens:
    if abs(r['hellmann_derivative'])>1e-8: print(r)
