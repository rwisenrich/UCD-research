# UCD 504 Fermionic Gap Workbench

This workbench projects the reconstructed H_504 Hamiltonian into the five 2D Dic6 irrep blocks and verifies the canonical fermionic gap.

Main finding:

- In every 2D Dic6 irrep block, there is a cluster gap equal to `(1/5)*exp(-tau)` to machine precision.
- Hellmann-Feynman sensitivity shows that this specific gap is carried by the leaf-ring term `T3_leaf_ring`, not by the current term `T6_curr_JZ`.
- The derivative with respect to the T3 coefficient is `2*exp(-tau)`, while the other term derivatives vanish for that gap pair.

Therefore, at canonical `kappa=0.1`, the gap is:

`Delta_F = 2*kappa*exp(-tau) = (1/5)*exp(-tau)`.
