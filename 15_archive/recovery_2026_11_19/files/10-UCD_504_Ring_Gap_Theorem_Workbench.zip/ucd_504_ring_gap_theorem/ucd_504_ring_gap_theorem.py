#!/usr/bin/env python3
"""
UCD 504 Ring-Gap Theorem Workbench

Reconstructs the documented H_504 scaffold, decomposes by Dic_6 irreps,
and verifies the universal ring-adjacency spectral cluster separation
Delta_ring = 2*kappa*exp(-tau).

This refines the previous "fermionic gap" observation: the same 2*kappa gap
exists in all Dic_6 irrep blocks; the 2D/fermionic blocks display it with
larger multiplicities.
"""
import numpy as np, math, csv, json, os, zipfile
from pathlib import Path

OUT = Path('/mnt/data/ucd_504_ring_gap_theorem')
OUT.mkdir(parents=True, exist_ok=True)

TAU = 1/72
EXP = math.exp(-TAU)
BASE_COEFF = np.array([1.0, 0.5, 0.1, 0.1, 1.1, 0.1, 0.3], dtype=float)
TERM_NAMES = [
    'T1_star_anchor',
    'T2_Z3_hopping',
    'T3_leaf_ring',
    'T4_central_parity_star',
    'T5_orient_XZ',
    'T6_current_JZ',
    'T7_leaf_generation_selector',
]

# Dic_6 = <a,x | a^12=1, x^2=a^6, x a x^-1 = a^-1>
ELEMS = [(k,e) for e in (0,1) for k in range(12)]
IDX = {g:i for i,g in enumerate(ELEMS)}

def dic6_mul(g,h):
    k,e = g; l,f = h
    return ((k + ((-1)**e)*l + (6 if e==1 and f==1 else 0)) % 12, e ^ f)

def dic6_inv(g):
    for h in ELEMS:
        if dic6_mul(g,h)==(0,0) and dic6_mul(h,g)==(0,0):
            return h
    raise ValueError(g)

def left_regular(g):
    M = np.zeros((24,24), complex)
    for j,h in enumerate(ELEMS):
        M[IDX[dic6_mul(g,h)], j] = 1
    return M

def right_regular(g):
    # right regular representation commuting with left action
    M = np.zeros((24,24), complex)
    gi = dic6_inv(g)
    for j,h in enumerate(ELEMS):
        M[IDX[dic6_mul(h, gi)], j] = 1
    return M

def chi_1d(eps_a, eps_b):
    return lambda g: (eps_a ** g[0]) * (eps_b ** g[1])

def chi_2d(j):
    # standard Dic_6 2D characters: zero on x-coset, 2cos(pi j k / 6) on a^k
    return lambda g: (2 * math.cos(math.pi * j * g[0] / 6) if g[1] == 0 else 0.0)

CHARACTERS = []
for ea in [1,-1]:
    for eb in [1,-1]:
        CHARACTERS.append(('1d', f'eps_a={ea},eps_b={eb}', chi_1d(ea, eb), 1))
for j in range(1,6):
    CHARACTERS.append(('2d', f'j={j}', chi_2d(j), 2))

def isotypic_projector(chi, dim):
    P = np.zeros((24,24), complex)
    for g in ELEMS:
        P += np.conj(chi(g)) * right_regular(g)
    return (dim/24) * P

def range_basis(P, tol=0.5):
    H = (P + P.conj().T)/2
    w, U = np.linalg.eigh(H)
    return U[:, w > tol]

def E(n,i,j):
    M = np.zeros((n,n), complex); M[i,j]=1; return M

def V7_ops():
    I = np.eye(7, dtype=complex)
    Pc = E(7,0,0)
    R7 = I - Pc
    A7 = np.zeros((7,7), complex)
    for i in range(1,7):
        A7[0,i] = A7[i,0] = 1
    Tp = np.zeros((7,7), complex)
    Tm = np.zeros((7,7), complex)
    for i in range(1,7):
        Tp[1+(i%6), i] = 1
        Tm[1+((i-2)%6), i] = 1
    Rring = Tp + Tm
    return I, Pc, R7, A7, Rring

def F3_ops():
    I = np.eye(3, dtype=complex)
    R = np.array([[0,1,0],[0,0,1],[1,0,0]], complex)
    XZ = R + R.conj().T
    JZ = (R - R.conj().T)/(1j*math.sqrt(3))
    P0mP2 = E(3,0,0) - E(3,2,2)
    return I, XZ, JZ, P0mP2

def kron3(A,B,C):
    return np.kron(np.kron(A,B),C)

I7, Pc, R7, A7, Rring = V7_ops()
I3, XZ, JZ, P0mP2 = F3_ops()
I24 = np.eye(24, dtype=complex)
La = left_regular((1,0))
Lx = left_regular((0,1))
La6 = left_regular((6,0))
rho_orient = 0.5*(La + La.conj().T)
rho_curr = 0.5*(Lx + Lx.conj().T)
BASE_TERMS_FULL = [
    (TERM_NAMES[0], A7, I3, I24),
    (TERM_NAMES[1], I7, XZ, I24),
    (TERM_NAMES[2], Rring, I3, I24),
    (TERM_NAMES[3], A7, I3, La6),
    (TERM_NAMES[4], I7, XZ, rho_orient),
    (TERM_NAMES[5], I7, JZ, rho_curr),
    (TERM_NAMES[6], R7, P0mP2, I24),
]

def clusters(eigs, tol=1e-8):
    vals = [float(x) for x in sorted(np.real(eigs))]
    out=[]; cur=[vals[0]]
    for x in vals[1:]:
        if abs(x-cur[-1]) < tol:
            cur.append(x)
        else:
            out.append((sum(cur)/len(cur), len(cur)))
            cur=[x]
    out.append((sum(cur)/len(cur), len(cur)))
    return out

def cluster_projector(H, center, tol=1e-7):
    w, U = np.linalg.eigh(H)
    ids = np.where(abs(w-center)<tol)[0]
    return U[:,ids] @ U[:,ids].conj().T, len(ids)

def block_terms_for_character(chi, dim):
    P = isotypic_projector(chi, dim)
    B = range_basis(P)
    terms = []
    for name,A,F,C in BASE_TERMS_FULL:
        Cb = B.conj().T @ C @ B
        terms.append((name, kron3(A,F,Cb)))
    return terms, B.shape[1], P

def block_hamiltonian(terms, coeff):
    H = sum(c*T for c,(_,T) in zip(coeff,terms)) * EXP
    return (H + H.conj().T)/2

def best_target_gaps(cl, target):
    centers = np.array([x for x,m in cl])
    adj = np.diff(centers)
    best_adj_idx = int(np.argmin(abs(adj-target))) if len(adj)>0 else -1
    best_adj_err = float(abs(adj[best_adj_idx]-target)) if len(adj)>0 else None
    best_pair_err = float('inf'); best_pair = None
    for i in range(len(centers)):
        for j in range(i+1, len(centers)):
            d = centers[j] - centers[i]
            err = abs(d-target)
            if err < best_pair_err:
                best_pair_err = float(err)
                best_pair = (i,j,float(d))
    return best_adj_idx, best_adj_err, best_pair_err, best_pair

# Projector checks and canonical gaps
proj_rows=[]; gap_rows=[]; sens_rows=[]
totalP = np.zeros((24,24), complex)
block_cache={}
for typ,name,chi,dim in CHARACTERS:
    terms, group_rank, P24 = block_terms_for_character(chi, dim)
    block_cache[name] = (terms, group_rank)
    totalP += P24
    proj_rows.append({
        'irrep_type': typ, 'irrep': name, 'irrep_dim': dim,
        'group_isotypic_rank': group_rank,
        'full_block_rank': 7*3*group_rank,
        'idempotency_error': float(np.linalg.norm(P24@P24-P24)),
    })
    H = block_hamiltonian(terms, BASE_COEFF)
    eigs = np.linalg.eigvalsh(H).real
    cl = clusters(eigs)
    target = 2*BASE_COEFF[2]*EXP
    ai, ae, pe, pair = best_target_gaps(cl, target)
    i,j,d = pair
    gap_rows.append({
        'irrep_type': typ, 'irrep': name, 'irrep_dim': dim,
        'full_block_rank': len(eigs), 'num_clusters': len(cl),
        'target_gap': target,
        'best_adjacent_gap_index': ai,
        'best_adjacent_error': ae,
        'best_pair_low_index': i, 'best_pair_high_index': j,
        'best_pair_gap': d, 'best_pair_error': pe,
        'low_center': cl[i][0], 'low_mult': cl[i][1],
        'high_center': cl[j][0], 'high_mult': cl[j][1],
    })
    # Hellmann sensitivity for the nearest adjacent target pair at canonical coefficients
    low_i, high_i = (ai, ai+1) if ai >= 0 else (i,j)
    Pl, dl = cluster_projector(H, cl[low_i][0])
    Pu, du = cluster_projector(H, cl[high_i][0])
    for idx,(tname,Tb) in enumerate(terms):
        deriv = EXP*((np.trace(Pu@Tb).real/du) - (np.trace(Pl@Tb).real/dl))
        sens_rows.append({
            'irrep_type': typ, 'irrep': name, 'term': tname,
            'hellmann_centroid_derivative': deriv,
            'expected_if_T3': 2*EXP if tname==TERM_NAMES[2] else 0.0,
            'abs_error_from_expected': abs(deriv - (2*EXP if tname==TERM_NAMES[2] else 0.0)),
        })

# coefficient invariance scans
np.random.seed(72)
scan_rows=[]
base=BASE_COEFF.copy()
for level in [0.1, 0.25, 0.5, 1.0, 2.0]:
    for trial in range(10):
        coeff = base.copy()
        for idx in [0,1,3,4,5,6]:
            coeff[idx] = base[idx]*(1 + level*np.random.randn())
        target = 2*coeff[2]*EXP
        for name,(terms,rank) in block_cache.items():
            H = block_hamiltonian(terms, coeff)
            cl = clusters(np.linalg.eigvalsh(H).real)
            ai,ae,pe,pair = best_target_gaps(cl,target)
            scan_rows.append({
                'scan_type':'vary_all_except_kappa', 'level': level, 'trial': trial, 'irrep': name,
                'kappa': coeff[2], 'target_2kappa_exp': target,
                'best_adjacent_error': ae, 'best_pair_error': pe,
                'best_pair_low_index': pair[0], 'best_pair_high_index': pair[1], 'best_pair_gap': pair[2],
            })
for kval in [0.01,0.05,0.1,0.2,0.7,-0.1]:
    coeff = base.copy(); coeff[2]=kval
    target = abs(2*kval*EXP)
    for name,(terms,rank) in block_cache.items():
        H = block_hamiltonian(terms, coeff)
        cl = clusters(np.linalg.eigvalsh(H).real)
        ai,ae,pe,pair = best_target_gaps(cl,target)
        scan_rows.append({
            'scan_type':'vary_kappa_only', 'level': kval, 'trial': 0, 'irrep': name,
            'kappa': coeff[2], 'target_2kappa_exp': target,
            'best_adjacent_error': ae, 'best_pair_error': pe,
            'best_pair_low_index': pair[0], 'best_pair_high_index': pair[1], 'best_pair_gap': pair[2],
        })

# Ring eigenvalue facts
ring_vals = np.linalg.eigvalsh(Rring).real
ring_clusters = clusters(ring_vals, tol=1e-10)
ring_rows=[]
for c,m in ring_clusters:
    ring_rows.append({'Rring_eigenvalue': c, 'multiplicity_in_V7': m})

# Write CSVs
def write_csv(path, rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
write_csv(OUT/'irrep_projector_checks.csv', proj_rows)
write_csv(OUT/'canonical_ring_gap_by_irrep.csv', gap_rows)
write_csv(OUT/'ring_gap_hellmann_sensitivities.csv', sens_rows)
write_csv(OUT/'ring_gap_invariance_scans.csv', scan_rows)
write_csv(OUT/'ring_adjacency_spectrum.csv', ring_rows)

summary = {
    'tau': TAU,
    'exp_minus_tau': EXP,
    'canonical_kappa': float(BASE_COEFF[2]),
    'canonical_target_gap_2_kappa_exp': float(2*BASE_COEFF[2]*EXP),
    'max_projector_idempotency_error': max(r['idempotency_error'] for r in proj_rows),
    'projector_sum_error': float(np.linalg.norm(totalP - np.eye(24))),
    'max_canonical_pair_gap_error': max(r['best_pair_error'] for r in gap_rows),
    'max_canonical_adjacent_gap_error': max(r['best_adjacent_error'] for r in gap_rows),
    'max_non_T3_sensitivity_abs': max(abs(r['hellmann_centroid_derivative']) for r in sens_rows if r['term'] != TERM_NAMES[2]),
    'max_T3_sensitivity_error': max(r['abs_error_from_expected'] for r in sens_rows if r['term'] == TERM_NAMES[2]),
    'max_invariance_pair_error': max(r['best_pair_error'] for r in scan_rows),
    'max_invariance_adjacent_error': max(r['best_adjacent_error'] for r in scan_rows),
    'ring_adjacency_eigenvalues': ring_rows,
    'interpretation': 'The observed (1/5) exp(-tau) gap is the canonical case of the universal ring-cluster separation 2*kappa*exp(-tau). It is not intrinsically fermion-only; it appears in every Dic_6 irrep block, with larger multiplicities in the 2D blocks.',
}
with open(OUT/'ring_gap_theorem_summary.json','w') as f:
    json.dump(summary,f,indent=2)

report = """# UCD 504 Ring-Gap Theorem Workbench

## Result

The earlier "fermionic gap" observation is real, but the cleaner statement is broader:

```math
Delta_ring = 2 kappa exp(-tau).
```

At the canonical value kappa = 1/10, this gives

```math
Delta_ring = (1/5) exp(-tau) = {target:.15f}.
```

The gap is carried by the leaf-ring adjacency term

```math
T_3 = R_ring \otimes I_3 \otimes I_24.
```

It is not carried by the current term and it is not a generic consequence of all coefficient choices if kappa itself is changed. Instead, the exact scaling is 2*kappa*exp(-tau).

## Numerical verification

- Projector sum error: {projector_sum:.3e}.
- Maximum projector idempotency error: {idem:.3e}.
- Maximum canonical pair-gap error across all 9 Dic6 irrep blocks: {pair:.3e}.
- Maximum canonical adjacent-gap error across all 9 blocks: {adj:.3e}.
- Maximum non-T3 Hellmann derivative magnitude: {nont3:.3e}.
- Maximum T3 derivative error from 2*exp(-tau): {t3err:.3e}.
- Maximum pair-gap error under coefficient scans with fixed kappa and under kappa scaling: {scanpair:.3e}.

## Proof skeleton

The 7-anchor ring operator is the cycle adjacency on the six leaf anchors with a separate center anchor. Its spectrum is

```math
spec(R_ring) = {{-2,-1,-1,0,1,1,2}}.
```

The star operator only couples the center anchor to the uniform leaf mode. Therefore, on the non-uniform leaf modes, the star terms vanish. The remaining non-ring terms either act only on the family/Dic6 factors or act as the identity on the relevant leaf subspaces. Hence matching family/Dic6 eigen-clusters are copied between ring eigenvalue -1 and ring eigenvalue +1 leaf sectors. Those two leaf-ring sectors differ by exactly

```math
(+1)-(-1)=2.
```

Multiplying by the Hamiltonian coefficient and the global scale gives

```math
Delta_ring = exp(-tau) * kappa * 2 = 2 kappa exp(-tau).
```

At kappa = 1/10, this is the observed machine-precision gap (1/5) exp(-tau).

## Interpretation

The result should be described as a ring-adjacency cluster-separation theorem for the 504-state Hamiltonian. It is not yet a particle-physics mass prediction, and it does not establish the separate claimed bosonic gap (1/2) exp(-tau).

The 2D Dic6 blocks make the gap look especially striking because their isotypic rank is 4, so the full block rank is

```math
7 * 3 * 4 = 84.
```

But the same 2*kappa*exp(-tau) ring-cluster separation exists in the 1D blocks as well.
""".format(
    target=2*BASE_COEFF[2]*EXP,
    projector_sum=summary['projector_sum_error'],
    idem=summary['max_projector_idempotency_error'],
    pair=summary['max_canonical_pair_gap_error'],
    adj=summary['max_canonical_adjacent_gap_error'],
    nont3=summary['max_non_T3_sensitivity_abs'],
    t3err=summary['max_T3_sensitivity_error'],
    scanpair=summary['max_invariance_pair_error'],
)
with open(OUT/'Ring_Gap_Theorem_Report.md','w') as f:
    f.write(report)

# zip package
zip_path = Path('/mnt/data/UCD_504_Ring_Gap_Theorem_Workbench.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in OUT.iterdir():
        if p.is_file():
            z.write(p, arcname=f'ucd_504_ring_gap_theorem/{p.name}')
print(json.dumps(summary,indent=2))
print(f'WROTE {zip_path}')
