# UCD 504 Ring-Gap Theorem Workbench

## Result

The earlier "fermionic gap" observation is real, but the cleaner statement is broader:

```math
Delta_ring = 2 kappa exp(-tau).
```

At the canonical value kappa = 1/10, this gives

```math
Delta_ring = (1/5) exp(-tau) = 0.197241423348783.
```

The gap is carried by the leaf-ring adjacency term

```math
T_3 = R_ring \otimes I_3 \otimes I_24.
```

It is not carried by the current term and it is not a generic consequence of all coefficient choices if kappa itself is changed. Instead, the exact scaling is 2*kappa*exp(-tau).

## Numerical verification

- Projector sum error: 2.698e-15.
- Maximum projector idempotency error: 2.237e-15.
- Maximum canonical pair-gap error across all 9 Dic6 irrep blocks: 6.106e-16.
- Maximum canonical adjacent-gap error across all 9 blocks: 6.106e-16.
- Maximum non-T3 Hellmann derivative magnitude: 6.569e-16.
- Maximum T3 derivative error from 2*exp(-tau): 8.882e-16.
- Maximum pair-gap error under coefficient scans with fixed kappa and under kappa scaling: 3.220e-15.

## Proof skeleton

The 7-anchor ring operator is the cycle adjacency on the six leaf anchors with a separate center anchor. Its spectrum is

```math
spec(R_ring) = {-2,-1,-1,0,1,1,2}.
```

The star operator only couples the center anchor to the uniform leaf mode. Therefore, on the non-uniform leaf modes, the star terms vanish. The remaining non-ring terms either act only on the family/Dic6 factors or act as the identity on the relevant leaf subspaces. Hence matching family/Dic6 eigen-clusters are copied between ring eigenvalue -1 and ring eigenvalue +1 leaf sectors. Those two leaf-ring sectors differ by exactly

```math
(+1)-(-1)=2.
```

Multiplying by the Hamiltonian coefficient and the global scale gives

```math
Delta_ring = exp(-tau) * kappa * 2 = 2 kappa exp(-tau).
```

At kappa = 1/10, this is the observed machine-precision gap (1/5) exp(-tau).

## Interpretation

The result should be described as a ring-adjacency cluster-separation theorem for the 504-state Hamiltonian. It is not yet a particle-physics mass prediction, and it does not establish the separate claimed bosonic gap (1/2) exp(-tau).

The 2D Dic6 blocks make the gap look especially striking because their isotypic rank is 4, so the full block rank is

```math
7 * 3 * 4 = 84.
```

But the same 2*kappa*exp(-tau) ring-cluster separation exists in the 1D blocks as well.
