# UCD-504 Driven Logical Dynamics Workbench

## Purpose

Test whether physical controls of the form

```math
H(t)=H_{504}+u_X(t)O_X+u_Z(t)O_Z
```

can implement logical rotations on the previously identified subsystem code

```math
\mathcal C_4\cong \mathcal L_2\otimes\mathcal G_2.
```

## Code and controls

- Code cluster: `j=1`, cluster `14`, energy `5.145571667152207`.
- Factorization residual for right-Dic6 gauge action: `3.422e-15`.
- Control library: left-Dic6 Hermitian operators.
- Fit residuals in the code/factor basis:
  - `O_X -> X_L \otimes I_G`: `7.359e-16`
  - `O_Y -> Y_L \otimes I_G`: `8.752e-16`
  - `O_Z -> Z_L \otimes I_G`: `5.912e-16`

## Projected code-level result

Inside the four-dimensional code subsystem, the fitted controls produce logical Pauli generators to numerical precision. See `projected_code_gate_sanity.csv`.

## Full j=1-block rectangular pulse test

For each gate, the workbench simulated

```math
U(t)=\exp[-i(H_b+A O)t],\qquad t=	heta/(2A),
```

where `H_b` is the `j=1` block and `O` is the fitted left-Dic6 control. The comparison removes the global cluster phase `exp(-i E_code t)` and then compares the code-compressed evolution against the ideal logical rotation.

The best rectangular-pulse results are stored in `best_pulse_by_gate.csv`; the full amplitude scan is in `driven_pulse_scan.csv`.

## Interpretation

The projected subsystem dynamics works: left-Dic6 controls act as logical Pauli generators and right-Dic6 remains gauge. The full block simulation exposes the next engineering problem: rectangular pulses can leak out of the code cluster unless pulse amplitude and duration are chosen carefully. This is the correct next boundary between a mathematical subsystem code and a physical driven-memory model.

## Next step

Replace rectangular pulses with shaped/adiabatic pulses and optimize the amplitude envelope to minimize leakage while preserving the logical rotation angle.
