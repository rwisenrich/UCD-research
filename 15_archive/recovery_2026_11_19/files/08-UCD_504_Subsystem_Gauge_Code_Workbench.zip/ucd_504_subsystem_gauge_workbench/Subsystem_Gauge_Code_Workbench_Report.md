# UCD-504 Subsystem/Gauge-Code Workbench

## Goal

Test whether the UCD-504 restricted exact code can be upgraded into a subsystem/gauge-code candidate for more realistic local errors.

The exact subsystem/QEC condition tested is

```text
P E_a^dagger E_b P = I_logical tensor M_ab
```

and the subspace special case is

```text
P E_a^dagger E_b P = c_ab P.
```

## Main discovery

A stronger candidate was found:

- Dic6 irrep block: `j=1`
- Spectral cluster: `14`
- Energy: `5.145571667152`
- Code dimension: `4`

This code space satisfies exact Knill-Laflamme to machine precision for arbitrary local matrix-unit errors on the V7 and family factors:

- V7 matrix-unit errors: max KL residual `2.405e-15`
- F3 matrix-unit errors: max KL residual `2.405e-15`
- V7 + F3 matrix-unit errors: max KL residual `2.405e-15`

That is stronger than the earlier 2D restricted code: it gives a 4D exact code space, enough for two logical qubits as a subspace code, for the V7/F3-local noise model.

## Boundary of the result

The same candidate fails natural Dic6 shift errors:

- Dic6 natural shifts max KL residual `2.000e+00`

So the correct claim is not arbitrary full 504-local noise. The correct claim is:

```text
UCD-504 contains a 4D exact code for arbitrary local errors on the anchor/ring and family factors, provided the Dic6 fiber is symmetry-preserved or treated as a separate gauge/syndrome structure.
```

## Files

- `subsystem_gauge_cluster_scan.csv`: scan over candidate clusters.
- `subsystem_gauge_best_candidates.csv`: best subsystem/gauge candidates by error model.
- `subsystem_local_transition_verification.csv`: direct verification of the new 4D code against full matrix-unit error sets.
- `subsystem_local_transition_summary.json`: machine-readable summary.
